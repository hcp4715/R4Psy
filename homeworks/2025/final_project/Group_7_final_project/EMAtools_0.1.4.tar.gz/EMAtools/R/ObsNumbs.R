#' Create observation numbers in your data
#'
#' This function allows you number your observations by participant (P), by day (D) or by participant and day (PD) using a unix (numeric) timestamp
#' @param ID name of ID variable
#' @param TS name unix (numeric) timestamp (if you have a date-time object, try converting it with as.numeric(as.POSIXct()))
#' @param BY participant (P), by day (D), or by participant and day (PD). P will create a column of just 1 through n responses for each participant. D will create a day-level sequential value. PD will create an observation within each day. This might be most useful by first using the BY=D option, which will give you day number to use in tandem with observation #.
#' @return A column in your dataframe (with person-centered data)
#' @keywords Observation Numbers
#' @export
#' @examples
#' \dontrun{data$ObsNumb<-ObsNumbs(data$ID,data$TS, BY="P")}
#' \dontrun{data$DayNumb<-ObsNumbs(data$ID,data$TS,BY="D")}
#' \dontrun{data$ObsNumb_D<-ObsNumbs(data$ID,data$TS,BY="PD")}

ObsNumbs<-function(ID,TS,BY=c("P","D","PD")){

  if (BY == "P"){
    ObsNumb_out<- ave(TS, ID, FUN = seq_along)
  }
  if (BY == "D"){
    PromptDate<-anytime::anydate(TS)
     ObsNumb_out<- ave(as.character(PromptDate),ID,FUN=function(x) as.numeric(factor(x)))
  }
  if (BY == "PD"){
    PromptDate<-anytime::anydate(TS)
    ObsNumb_out<- ave(TS, paste(ID,PromptDate), FUN = seq_along)
  }
  return(ObsNumb_out)
}



