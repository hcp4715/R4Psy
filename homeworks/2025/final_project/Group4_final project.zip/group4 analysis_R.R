# 设置工作目录（根据实际数据路径修改）
setwd("D:/Code/R2/R4Psy/homeworks/2025/data")
options(repos = c(CRAN = "https://mirrors.tuna.tsinghua.edu.cn/CRAN/"))
library(tidyverse)
library(magrittr)
library(emmeans)
library(readxl)
library(lme4)
library(lmerTest)
library(lubridate)
library(car)
library(stats)
##################
# Child Results: #
##################

all_exps <- read_csv("all_exps.csv")
# 实验五：4vs6条件选择行为分析
exp5 <- read_csv("all_exps.csv") %>% 
      filter(id == "exp5_4v6")  # 筛选实验五数据

report_results <- function(df, study){
      df %>%
            dplyr::filter(id == study) %>%
            glmer(
                  formula = choice ~ 1 + trial + (1|pid),
                  data = .,
                  family = "binomial",
                  control = glmerControl(optimizer = "bobyqa"),
                  contrasts = list(trial = "contr.sum")
            ) -> res1
      
      df %>%
            dplyr::filter(id == study) %$%
            fisher.test(x = choice, y = trial_type) -> res2
      
      print(res1 %>% summary)
      print(res2)
}

# Report glmer + fisher.test results
report_results(all_exps, "exp1")
report_results(all_exps, "exp2")
report_results(all_exps, "exp3")
report_results(all_exps, "exp4_1v7")
report_results(all_exps, "exp4_3v5")
report_results(all_exps, "exp4_4v6")
report_results(all_exps, "exp5_4v6")

# ANOVA
all_exps %>%
      dplyr::filter(id != "exp_rep") %>% # Exclude replication study
      glmer(
            formula = choice ~ 1 + scale(age) * trial * id + (1|pid),
            data= .,
            family = "binomial",
            contrasts = list(trial = "contr.sum"),
            control = glmerControl(optimizer="bobyqa")
      ) %>%
      Anova(type = "2")

##################
# Adult Results: #
##################

adult <- read_csv("adult_data.csv")
# Pivot to long form
adult %>%
      drop_na() %>%
      mutate(
            pid = row_number(),
            id = case_when(
                  Experiment == "Exp1" ~ "exp1",
                  Experiment == "4vs6" ~ "exp4_4v6",
                  Experiment == "3vs5" ~ "exp4_3v5",
                  Experiment == "1vs7" ~ "exp4_1v7",
            ),
            trial_1 = case_when(
                  Score == 2 ~ 1,
                  Score == 1 ~ 1,
                  Score == 0 ~ 0,
            ),
            trial_2 = case_when(
                  Score == 2 ~ 1,
                  Score == 1 ~ 0,
                  Score == 0 ~ 0,
            )) %>%
      pivot_longer(
            c(trial_1, trial_2),
            names_to = "trial",
            values_to = "choice"
      ) -> adult

report_adults <- function(df, study){
      df %>%
            dplyr::filter(id == study) %>%
            glmer(
                  formula = choice ~ 1 + (1|pid),
                  data = .,
                  family = "binomial",
                  control = glmerControl(optimizer = "bobyqa")
            ) -> res1
      print(res1 %>% summary)
}

report_adults(adult, "exp1")
report_adults(adult, "exp4_1v7")
report_adults(adult, "exp4_3v5")
report_adults(adult, "exp4_4v6")

##################
# Age comparison #
##################

all_data = read_csv("all_data.csv")

all_data %>%
      glm(
            formula = choice ~ 1 + age_group * experiment,
            data = .,
            family = "binomial",
            contrasts = list(
                  age_group = "contr.sum",
                  experiment = "contr.sum"
            ),
      ) %>%
      Anova(type = 2)

all_data %>%
      glm(
            formula = choice ~ 1 + age_group * experiment,
            data = .,
            family = "binomial",
            contrasts = list(
                  age_group = "contr.sum",
                  experiment = "contr.sum"
            ),
      ) %>%
      emmeans("age_group", by = "experiment") %>%
      pairs(infer = c(TRUE, TRUE))