# Experiment 2

These scripts are provided by Steven Cao, a master's student in the CAB lab (PI: Monica Rosenberg) who collected the data for Experiment 2 for his master's thesis.

Note that they are not intended to be executed from this directory directly. Rather, they are included for distribution of this project to comprehensively illustrate any of the data fields. 
