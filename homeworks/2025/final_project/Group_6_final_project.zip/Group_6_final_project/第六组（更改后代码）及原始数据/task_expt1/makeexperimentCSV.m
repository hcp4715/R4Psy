% Get the list of images to be uploaded to the memorability task
%
% Wilma Bainbridge
% April 5 2019

clear all
close all

%% Set up variables
% Number of stimuli for each condition: 8/12/20
numtargets = 60;
numfoils = 76;
numtrialspertarget = 40;

% load in the stimuli, in the two different directories (separated by
% indoor and outdoor)
dir1 = '..\stim\sunindoor550\';
diry1 = dir([dir1 '*.jpg']);
dir2 = '..\stim\sunoutdoor550\';
diry2 = dir([dir2 '*.jpg']);

counter = 1;

%% Create participant-stimulus pool
% Loop through each stimulus and create a "pool" of 40 participants, that
% gets taken out of each time the stimulus is used. This way we get the #
% of participants per stimuli that they want.

% Do this for the indoor images
for d = 1:length(diry1)
    tempname = diry1(d).name;
    unders = strfind(tempname, 'sun');
    tempname = tempname(unders(1)+4:end-4);
    imnames{counter} = tempname; % Save a dictionary of file names without the "sun_" prefix
    totalcount(counter) = numtrialspertarget;
    counter = counter+1;
end
% Do this for the outdoor images
for d = 1:length(diry2)
    tempname = diry2(d).name;
    unders = strfind(tempname, 'sun');
    tempname = tempname(unders(1)+4:end-4);
    imnames{counter} = tempname; % Save a dictionary of file names without the "sun_" prefix
    totalcount(counter) = numtrialspertarget;
    counter = counter+1;
end
totalims = counter-1;

%% If you have already run some trials, take those into consideration
% load('..\data_expt1\memdata-30-Jun-2021.mat');
% for c = 1:length(imdata)
%    name = imdata(c).name; 
%    unders = strfind(name, 'sun');
%    if ~isempty(unders)
%    name = name(unders(1)+4:end-4);
%    spot = find(ismember(imnames,name));
%        tosubtract = imdata(c).target.hits + imdata(c).target.misses;
%        totalcount(spot) = totalcount(spot) - tosubtract;
%    end
% end

%% Now make the trial orders for participants
fid = fopen(['imorder-' date '.csv','w');
% print out the header
for c = 1:numtargets+numfoils-1
    fprintf(fid,'image%d,',c);
end
fprintf(fid,'image%d\n',numtargets+numfoils);

% print out each item
while sum(totalcount) > 0
    randlisting = find(totalcount>0);
    randlisting = randlisting(randperm(length(randlisting)));
    
    counter = 1;
    imssofar = [];
    for r = 1:numtargets % list out the targets first
        if counter > length(randlisting) % if it's run out of images to use, populate with random others)
            possibleims = setdiff(1:totalims,imssofar);
            randim = possibleims(randi(length(possibleims)));
            imssofar = [imssofar randim];
            fprintf(fid,'sun_%s.jpg,', imnames{randim});
        else % if there are still images to use
            imssofar = [imssofar randlisting(counter)];
            fprintf(fid,'sun_%s.jpg,', imnames{randlisting(counter)});
            totalcount(randlisting(counter)) = totalcount(randlisting(counter)) - 1;
            counter = counter + 1;
        end
    end
    for r = 1:numfoils-1 % list out the fillers after
        if counter > length(randlisting) % if it's run out of images to use, populate with random others)
            possibleims = setdiff(1:totalims,imssofar);
            randim = possibleims(randi(length(possibleims)));
            imssofar = [imssofar randim];
            fprintf(fid,'sun_%s.jpg,', imnames{randim});
        else % if there are still images to use
            imssofar = [imssofar randlisting(counter)];
            fprintf(fid,'sun_%s.jpg,', imnames{randlisting(counter)});
            counter = counter + 1;
        end
    end
    % print out the final image
    if counter > length(randlisting) % if it's run out of images to use, populate with random others)
        possibleims = setdiff(1:totalims,imssofar);
        randim = possibleims(randi(length(possibleims)));
        fprintf(fid,'sun_%s.jpg\n', imnames{randim});
    else % if there are still images to use
        fprintf(fid,'sun_%s.jpg\n', imnames{randlisting(counter)});
    end
end

fclose(fid);

%% Here is text that can go into the experimental code
% print out the text for the experiment stimulus listing
URL = 'http://wilmabainbridge.com/research/AttMem/';
output = 'var images1 = new Array("';
for c = 1:numtargets+numfoils-1
    output = [output URL '${image' num2str(c) '}", "'];
end
output = [output URL '${image' num2str(c) '}");'];
disp(output);

% preloading code at the end
URL = 'http://wilmabainbridge.com/research/AttMem/';
output = [];
for c = 1:numtargets+numfoils
    output = [output '<img src="' URL '${image' num2str(c) '}" height=1 width=1> '];
end
disp(output);