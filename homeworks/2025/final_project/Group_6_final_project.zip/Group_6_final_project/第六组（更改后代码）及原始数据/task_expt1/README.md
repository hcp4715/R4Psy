# Experiment 1

These tasks were used to obtain memorability ratings for these images. Note that the data were collected on Amazon Mechanical Turk
