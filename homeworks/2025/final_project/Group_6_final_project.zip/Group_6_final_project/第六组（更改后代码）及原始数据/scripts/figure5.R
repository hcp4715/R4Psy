library(tidyverse)
library(lme4)
library(optimx)
library(mousetrap)
library(plotrix)
library(ggpubr)
library(patchwork)
#library(showtext)

rm(list=ls())


######################## Load & filter data ######################## 
# read in memorablity data
mem <- read.csv("./data_expt1/memscores-30-Jun-2021.csv")%>%
  rename(imagename=filename)%>%
  mutate(cr=hr-far)

# read in attention data and make distinct subject numbers
att_exp2 <- read.csv("./data_expt2/Expt2_attnmem.csv")%>%
  mutate(exp="exp2")
att_exp2$subject_num = att_exp2$subject_num+100

att_exp3 <- read.csv("./data_expt3/Expt3_attnmem.csv")%>%
  mutate(exp="exp3")
att_exp3$subject_num = att_exp3$subject_num+200

# join attention data, keep only infrequent category trials, exclude subjects for poor attention task performance
all_att <- rbind(att_exp3,att_exp2)%>%
  filter( subject_num!=125 & subject_num!=226)%>%
  rename(imagename=image_name)

is.nan.data.frame <- function(x)
  do.call(cbind, lapply(x, is.nan))

all_att[is.nan(all_att)] <- NA
all_att$subject_num <- factor(all_att$subject_num)
all_att$exp <- factor(all_att$exp)
all_att$attn_acc <- factor(all_att$attn_acc)

# add image category to memorability data
mem2 <- merge(mem, all_att[, c("image_categname", "imagename")], by ="imagename", all = TRUE)
mem2 <- mem2[!duplicated(mem2$imagename),]

# filter to keep only infrequent trials
all_att <- all_att %>% filter((subject_infreq_categ == "indoor" & image_categname == "indoor")|(subject_infreq_categ == "outdoor" & image_categname == "outdoor"))

#merge memorability and attention data
all_att_memorab <- merge(all_att,mem, by ="imagename")
all_att_memorab <- all_att_memorab %>%
  mutate(mem_remembered_thr4= ifelse(all_att_memorab$mem_rating == 4, 1, 0))

attmem_drop_na<-all_att_memorab%>%
  dplyr::select(mem_remembered_thr4, cr,attn_pretrial_rtsresid, subject_num, exp, image_num,attn_trialnum)%>%
  drop_na()
attmem_drop_na$subject_num <- factor(attmem_drop_na$subject_num)
attmem_drop_na <- scale_within(attmem_drop_na, variables=c("attn_pretrial_rtsresid", "cr"), within="subject_num",prefix="scale_")
attmem_drop_na_exp2 <- attmem_drop_na %>%
  filter(exp=="exp2")
attmem_drop_na_exp3 <- attmem_drop_na %>%
  filter(exp=="exp3")

######################## Within-subject logistic regression models ######################## 
# Within subject joint model- both exps
within_sub_joint_model_coefs <- data.frame(exp = numeric(0), subject_num=numeric(0), intercept=numeric(0), cr_coef=numeric(0), attn_pretrial_rtsresid_coef=numeric(0))
for (i in unique(attmem_drop_na$subject_num)){
  within_sub_model <- glm(mem_remembered_thr4 ~ scale_cr + scale_attn_pretrial_rtsresid, data=attmem_drop_na[attmem_drop_na$subject_num==i,], family=binomial(link = "logit"))
  tmp              <- data.frame(exp = numeric(0), subject_num=numeric(0), intercept=numeric(0), cr_coef=numeric(0), attn_pretrial_rtsresid_coef=numeric(0))
  tmp[1,]          <- c(unique(attmem_drop_na[attmem_drop_na$subject_num==i,]$exp), i, within_sub_model$coefficients)
  within_sub_joint_model_coefs <- rbind(within_sub_joint_model_coefs,tmp)
}

within_sub_joint_model_coefs <- within_sub_joint_model_coefs[order(within_sub_joint_model_coefs$exp, within_sub_joint_model_coefs$subject_num), ]
within_sub_joint_model_coefs$intercept                        <- as.numeric(within_sub_joint_model_coefs$intercept)
within_sub_joint_model_coefs$cr_coef                          <- as.numeric(within_sub_joint_model_coefs$cr_coef)
within_sub_joint_model_coefs$attn_pretrial_rtsresid_coef      <- as.numeric(within_sub_joint_model_coefs$attn_pretrial_rtsresid_coef)

within_sub_joint_model_coefs$exp         <- gsub('2', 'Experiment 3', within_sub_joint_model_coefs$exp)
within_sub_joint_model_coefs$exp         <- gsub('1', 'Experiment 2', within_sub_joint_model_coefs$exp)
within_sub_joint_model_coefs$exp         <- as.factor(within_sub_joint_model_coefs$exp)
within_sub_joint_model_coefs$subject_num <- as.factor(within_sub_joint_model_coefs$subject_num)
within_sub_joint_model_coefs             <- within_sub_joint_model_coefs[order(within_sub_joint_model_coefs$exp, within_sub_joint_model_coefs$subject_num), ]

# Reshape for plotting
within_sub_joint_model_coefs_long        <- within_sub_joint_model_coefs %>% gather(key = "factor", value = "value", cr_coef, attn_pretrial_rtsresid_coef, -c(subject_num,exp))
within_sub_joint_model_coefs_long$factor <- factor(within_sub_joint_model_coefs_long$factor, levels = c("cr_coef","attn_pretrial_rtsresid_coef"))
within_sub_joint_model_coefs_long        <- within_sub_joint_model_coefs_long[order(within_sub_joint_model_coefs_long$exp, within_sub_joint_model_coefs_long$subject_num), ]


############################ Generate figures ############################  
# colors
r_dark = rgb(162/255, 39/255, 69/255)
r_light = rgb(226/255, 108/255, 132/255)
b_dark = rgb(35/255, 80/255, 147/255)
b_light = rgb(90/255, 148/255, 206/255)
p_dark = rgb(99/255, 60/255, 108/255)
p_light = rgb(158/255, 128/255, 169/255)

# themes
fig5a_theme <- theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
                     panel.background = element_blank(), legend.position = "none", 
                     axis.line = element_line(colour = "grey") ,
                     axis.title.x = element_blank(),
                     axis.ticks = element_blank(),
                     axis.title.y = element_text(size = 24, margin=margin(0,12,0,0)),
                     axis.text = element_text(size = 20),
                     strip.background = element_blank(),
                     strip.text.x = element_text(size = 24, margin=margin(10,0,0,0)),
                     strip.placement = "outside",
                     panel.spacing.x=unit(1, "lines"))

fig5b_theme <- theme(panel.grid.major = element_blank(),
                     panel.grid.minor = element_blank(),
                     panel.background = element_blank(),
                     axis.line = element_line(colour = "grey"),
                     legend.position="none",
                     axis.ticks = element_blank(),
                     axis.title.x = element_text(size = 24, margin=margin(20,0,1,0)),
                     axis.title.y = element_text(size = 24, margin=margin(0,12,0,0)),
                     axis.text = element_text(size = 20))
  
# Bar plot
bar_plot <- ggplot(data=within_sub_joint_model_coefs_long, aes(x=factor, y=value, fill = interaction(factor,exp)))+
  facet_wrap(~exp, scales = "fixed", strip.position = "bottom") +
  geom_bar(colour="black", alpha=.7, stat="summary", fun = "mean", position = position_dodge(.75), width=.5) +
  geom_point(size=2, stroke = 0,position = position_dodge(width=0.75),color="black",alpha=.15) + 
  geom_abline(slope = 0,intercept = 0, color="grey") +
  scale_color_manual(values = c(r_dark,b_dark,r_light,b_light)) +
  scale_fill_manual(values = c(r_dark,b_dark,r_light,b_light)) +
  scale_x_discrete(labels=c("Memorability", "Attention")) +
  ylim(-1,2)+
  labs(y="Coefficient") +
  coord_cartesian(clip = "off") + 
  fig5a_theme

# Scatter plot
corr_plot <- ggplot(within_sub_joint_model_coefs, aes(attn_pretrial_rtsresid_coef, cr_coef,color=exp))+
  geom_smooth(method="lm")+
  geom_point(size=3,stroke=0,alpha=.75)+
  scale_color_manual(values=c(p_dark,p_light),labels = c("Experiment 2", "Experiment 3"))+
  expand_limits(y=c(-1,2), x=c(-1,2))+
  labs(
    x="Attention Coefficient",
    y="Memorability Coefficient",
    color= "Experiment")+
  scale_x_continuous(breaks=c(-1,0,1,2), limits=c(-1,2))+
  scale_y_continuous(breaks=c(-1,0,1,2), limits=c(-1,2))+
  annotate("text", x=1.3, y=1.75, label= "Experiment 2", size=7,color=p_dark)+
  annotate("text", x=1.3, y=1.475, label= "Experiment 3",size=7,color=p_light) + 
  fig5b_theme

############# SAVE FIGURE #############
#showtext_auto()

pdf(file = "figures/figure5.pdf",   
    width = 13, 
    height = 5) 

figure5<- ggarrange(NULL,NULL,NULL,bar_plot,NULL,corr_plot,
                    widths = c(1.2,.08,.675),
                    heights = c(.11,1),
                    labels = c("a","b"),
                    label.x = 0,
                    label.y = 1,
                    font.label = list(color="Black",size = 32),
                    ncol = 3, nrow = 2)
figure5

dev.off()
#showtext_auto(FALSE)