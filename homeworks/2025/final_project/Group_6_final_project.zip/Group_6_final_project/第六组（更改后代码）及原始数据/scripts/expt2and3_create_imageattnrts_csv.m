%expt2and3_create_imageattnrts_csv.m
%
%this is to create csvs used to examine whether sustained attention 
%(RTs to frequent trials) is related to memorability
%
%code written by MdB 07/2021

%% Expt 2

expt_dir = './../data_expt2/';

all_subj = 1:37;
excluded_subj = [10,12,21];
all_subj = setdiff(all_subj,excluded_subj);
nsubj = numel(all_subj);

subj_dat = struct();
subj_dat.subject_num = [];
subj_dat.rts_freq = [];
subj_dat.image_name_freq = [];
subj_dat.acc_freq = [];
subj_dat.trial_num_freq = [];
subj_dat.categ_freq = [];
T = table();

for isubj = 1:nsubj
    subject_num = all_subj(isubj);
    
    %load attention data
    fn = deblank(ls([expt_dir '/subjects/' num2str(subject_num) '/attndata_*']));
    load(fn);
    
    %load memory data 
    fn = deblank(ls([expt_dir '/subjects/' num2str(subject_num) '/memdata_*']));
    load(fn)
    
    %extract relevant information from trials where the image presented belonged to the frequent category 
    subj_dat.subject_num = ones(sum(attnData.categs==mode(attnData.categs)),1)*subject_num;
    subj_dat.rts_freq = (attnData.rts(attnData.categs==mode(attnData.categs)))';
    subj_dat.image_name_freq = (attnData.imageName(attnData.categs==mode(attnData.categs)))';
    subj_dat.acc_freq = (attnData.accs(attnData.categs==mode(attnData.categs)))';
    subj_dat.trial_num_freq = (find(attnData.categs==mode(attnData.categs)))';
    subj_dat.categ_freq = (attnData.categs(attnData.categs==mode(attnData.categs)))';
    
    %convert to table
    subj_table = struct2table(subj_dat);

    T = [T; subj_table];
end

%save variables

fn_save = [expt_dir '/expt2_imageattnrts.csv'];
writetable(T,fn_save)


%% Expt 3

expt_dir = './../data_expt3/';

all_subj = 3:27;
nsubj = numel(all_subj);

subj_dat = struct();
subj_dat.subject_num = [];
subj_dat.rts_freq = [];
subj_dat.image_name_freq = [];
subj_dat.acc_freq = [];
subj_dat.trial_num_freq = [];
subj_dat.categ_freq = [];
T = table();

for isubj = 1:nsubj
    subject_num = all_subj(isubj);
    
    %load attention data
    fn = deblank(ls([expt_dir '/subjects/' num2str(subject_num) '/blockdata_1_*']));
    load(fn);
    
    %load memory data 
    fn = deblank(ls([expt_dir '/subjects/' num2str(subject_num) '/memdata_*']));
    load(fn)
    
    %extract relevant information from trials where the image presented belonged to the frequent category 
    subj_dat.subject_num = ones(sum(blockData.categs==mode(blockData.categs)),1)*subject_num;
    subj_dat.rts_freq = (blockData.rts(blockData.categs==mode(blockData.categs)))';
    subj_dat.image_name_freq = (blockData.imageName(blockData.categs==mode(blockData.categs)))';
    subj_dat.acc_freq = (blockData.accs(blockData.categs==mode(blockData.categs)))';
    subj_dat.trial_num_freq = (find(blockData.categs==mode(blockData.categs)))';
    subj_dat.categ_freq = (blockData.categs(blockData.categs==mode(blockData.categs)))';
    
    %convert to table
    subj_table = struct2table(subj_dat);

    T = [T; subj_table];
end

%save variables

fn_save = [expt_dir '/expt3_imageattnrts.csv'];
writetable(T,fn_save)