% Memorability Consistency Analyses
%
% This script looks at the consistency in people's memory performance for
% the images
%
% Wilma Bainbridge
% June 29 2021

% Recode the consistency analyses to ensure they are working totally
% correctly

clear all
close all

%% Change file paths here
load('../data_expt1/memdata-30-Jun-2021.mat');
figfile = ['../data_expt1/consistencyfigure-' date '.fig'];
savefile = ['../data_expt1/consistencyanalysis-' date '.mat'];
figureoutputsfile = ['../data_expt1/consistencyfiguredata-' date '.csv'];
iterations = 1000; % how many iterations of the analysis (1000 can take a while!)

%% These are constants defined in the experiment script for image type and performance
FIXATION = 0;
TARGET = 1;
REPEAT = 2;
FILLER = 3;
VIGILANCE = 4;

HIT = 11;
MISS = 12;
FALSEALARM = 13;
CORRECTREJECTION = 14;

% Initialize various variables
numstim = length(imdata);
numsubs = length(subdata);
subslist = {subdata.name};
imslistdict = {imdata.name};

for it = 1:iterations
    % Repeat the consistency analysis across the number of specified
    % iterations
    
    disp(['Iteration #' num2str(it)]);
    
    % Split the participants into two random halves
    randlist = randperm(length(subslist));
    firsthalf = randlist(1:floor(length(randlist)/2));
    secondhalf = randlist(floor(length(randlist)/2)+1:end);
    
    % Initialize performance arrays for that first half
    hits1 = zeros(length(firsthalf),numstim);
    fas1 = zeros(length(firsthalf),numstim);
    hrtotal1 = zeros(length(firsthalf),numstim);
    fatotal1 = zeros(length(firsthalf),numstim);
    
     % Initialize performance arrays for that second half
    hits2 = zeros(length(secondhalf),numstim);
    fas2 = zeros(length(secondhalf),numstim);
    hrtotal2 = zeros(length(secondhalf),numstim);
    fatotal2 = zeros(length(secondhalf),numstim);
    
    %% Calculate memory performance for participant half 1
    for c = 1:length(firsthalf)
        % Get their performance measures
        imvec = subdata(firsthalf(c)).imorder;
        imtypes = subdata(firsthalf(c)).imtypeorder;
        imperf = subdata(firsthalf(c)).perforder;
         
        for im = 1:length(imtypes) % Go through each image they saw
            imid = imvec{im};
            
            % get the ID for the image
            idloc = find(ismember(imslistdict,imid));
            
            % Note if they made a false alarm to that image
            if imtypes(im) == TARGET && imperf(im) == FALSEALARM
                fas1(c,idloc) = 1;
            end
            % Note if they made a hit to that image
            if imtypes(im) == REPEAT && imperf(im) == HIT
                hits1(c,idloc) = 1;
            end
            % Note if was presented as a target for the 1st time
            if imtypes(im) == TARGET
                fatotal1(c,idloc) = 1;
            end
            % Note if it was presented as a target for the 2nd time
            if imtypes(im) == REPEAT
                hrtotal1(c,idloc) = 1;
            end
        end
    end
    
    % Calculate the HR across images
    sumhits1 = sum(hits1,1);
    sumhrtotal1 = sum(hrtotal1,1);
    hr1(it,:) = sumhits1 ./ sumhrtotal1;
    
    % Calculate the FAR across images
    sumfas1 = sum(fas1,1);
    sumfatotal1 = sum(fatotal1,1);
    far1(it,:) = sumfas1 ./ sumfatotal1;
    
    % Calculate the CR across images
    cr1(it,:) = hr1(it,:) - far1(it,:);
    
    
    %% Calculate memory performance for participant half 2
    for c = 1:length(secondhalf)
        % Get their performance measures
        imvec = subdata(secondhalf(c)).imorder;
        imtypes = subdata(secondhalf(c)).imtypeorder;
        imperf = subdata(secondhalf(c)).perforder;
        
        for im = 1:length(imtypes) % Go through each image they saw
            imid = imvec{im};
            
           % get the ID for the image
             idloc = find(ismember(imslistdict,imid));

            % Note if they made a false alarm to that image
            if imtypes(im) == TARGET && imperf(im) == FALSEALARM
                fas2(c,idloc) = 1;
            end
            % Note if they made a hit to that image
            if imtypes(im) == REPEAT && imperf(im) == HIT
                hits2(c,idloc) = 1;
            end
            % Note if was presented as a target for the 1st time
            if imtypes(im) == TARGET
                fatotal2(c,idloc) = 1;
            end
            % Note if it was presented as a target for the 2nd time
            if imtypes(im) == REPEAT
                hrtotal2(c,idloc) = 1;
            end
        end
    end
    
    % Calculate the HR across images
    sumhits2 = sum(hits2,1);
    sumhrtotal2 = sum(hrtotal2,1);
    hr2(it,:) = sumhits2 ./ sumhrtotal2;
    
    % Calculate the FAR across images
    sumfas2 = sum(fas2,1);
    sumfatotal2 = sum(fatotal2,1);
    far2(it,:) = sumfas2 ./ sumfatotal2;
    
    % Calculate the CR across images
    cr2(it,:) = hr2(it,:) - far2(it,:);
    
    %% Now see how similarly the split halves performed
    % Correlate CR with the first and second halves
    rank_corr(it) = corr(cr1(it,:)',cr2(it,:)','type','Spearman','rows','complete');
    
    % Sort both scores from high to low memorability
    [cr1(it,:),ind] = sort(cr1(it,:),'descend');
    bloop = cr2(it,:);
    cr2(it,:) = bloop(ind);
    
    % Also create a random sorting and perform the correlation, to estimate
    % chance
    cr3(it,:) = bloop(randperm(length(bloop)));
    rand_corr(it) = corr(cr1(it,:)',cr3(it,:)','type','Spearman','rows','complete');
end

%% Plot the memorability curve figure

% Get averages across the iterations
meancr1 = nanmean(cr1);
meancr2 = nanmean(cr2);
meancr3 = nanmean(cr3);
deletespots = isnan(meancr1) & isnan(meancr2) & isnan(meancr3);
meancr1(deletespots) = [];
meancr2(deletespots) = [];
meancr3(deletespots) = [];

% Now handle plotting
figure;

% Uncomment this if you want to smooth the lines
%meanhr2 = conv(meanhr2, ones(1,25)./25,'valid');
%meanhr3 = conv(meanhr3, ones(1,25)./25,'valid');

plot(meancr1);
hold on
plot(meancr2);
plot(meancr3);
set(gca, 'XLim',[1,length(meancr1)]);

title(nanmean(rank_corr));
savefig(figfile);

%% Save the data for creating the curve to a CSV file so it can be used to generate figures in other programs (e.g., R)

fid = fopen(figureoutputsfile,'w');

% Mean Group 1 memorability for each image
fprintf(fid, 'group1');
for im = 1:length(meancr1)
    fprintf(fid, ',%.5f', meancr1(im));
end

% Mean Group 2 memorability for each image
fprintf(fid, '\ngroup2');
for im = 1:length(meancr2)
    fprintf(fid, ',%.5f', meancr2(im));
end

% Mean Chance memorability for each image
fprintf(fid, '\nchance');
for im = 1:length(meancr3)
    fprintf(fid, ',%.5f', meancr3(im));
end

fclose(fid);

%% Calculate the p-value

meanconsistency = nanmean(rank_corr);
pval = (sum(abs(rank_corr) <= abs(rand_corr)) + 1) / (iterations + 1);

%% Get the 95% confidence intervals
sortedcorrs = sort(rank_corr);
intervalspot = length(rank_corr) * 0.05;
confinterval = [sortedcorrs(intervalspot) sortedcorrs(end-intervalspot+1)];

%% Save enough data that you do not need to run the iterations again if you want to look back at the data
save(savefile, 'pval','confinterval','rank_corr','rand_corr','hr1','hr2','far1','far2','cr1','cr2','cr3');
