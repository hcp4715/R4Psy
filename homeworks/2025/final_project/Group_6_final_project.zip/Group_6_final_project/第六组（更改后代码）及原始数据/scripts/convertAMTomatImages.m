% Convert AMT Output to MATLAB
%
% Wilma Bainbridge
%
% January 5, 2017
%
% This script takes the data from a Mechanical Turk memorability task and
% converts it to MATLAB-ready memory performance data.
%
% To get to this step you will need to:
% - Open the .CSV created by Mechanical Turk in Excel
% - Replace all , with ; and save the file
% - Change csvfiles (line 22) to all relevant CSV files
% - Change savefile (line 23) to what you want the data to be saved as


clear all
close all

%% Change file paths here

csvfiles = {'../data_expt1/fin_batch_1.csv','../data_expt1/fin_batch_2.csv','../data_expt1/fin_batch_3.csv','../data_expt1/fin_batch_4.csv','../data_expt1/fin_batch_5.csv','../data_expt1/fin_batch_6.csv'};
matsavefile = ['../data_expt1/memdata-' date '.mat']; % save with the date so old files aren't overwritten
memorabilityscoresCSV = ['../data_expt1/memscores-' date '.csv'];
memorabilityscoresMAT = ['../data_expt1/memscores-' date '.mat'];

%% These are constants defined in the experiment script for image type and performance

% Image type
FIXATION = 0;
TARGET = 1;
REPEAT = 2;
FILLER = 3;
VIGILANCE = 4;

% Performance
HIT = 11;
MISS = 12;
FALSEALARM = 13;
CORRECTREJECTION = 14;

% Initialize various variables
imdictionary = {};
dicount = 1;
subcount = 1;


%% Import the data

for c1 = 1:length(csvfiles)
    
    % load in the data from each CSV file
    csvfile = csvfiles{c1};
    data = readtable(csvfile,'Delimiter',',','ReadVariableNames',1,'HeaderLines',0);
    
    numsubs = size(data,1);
    
    for sub = 1:numsubs
        % For each online participant (each row), save their data
        
        subdata(subcount).name = data.WorkerId{sub};
        imorder = data.Answer_imseq{sub};
        use = data.Approve{sub};
        
        %% Save subject data
        % If they saw images (i.e., ran the experiment), and were Approved
        % on AMT, then use their data
        if ~isempty(imorder) && ~strcmp(imorder,'{}') && ~isempty(use)
            % Get image type and performance vectors
            imtypeorder = data.Answer_imtypeseq{sub};
            perforder = data.Answer_perfseq{sub};
            
            % Remove fixation trials
            imorder = strrep(imorder, 'fixation.jpg;', '');
            imorder = strrep(imorder, ';fixation.jpg', '');
            imorder = strsplit(imorder, ';');
            imtypeorder = strrep(imtypeorder, '0;', '');
            imtypeorder = str2num(imtypeorder);
            imtypeorder(imtypeorder==0) = []; % take out final fixation
            perforder = str2num(perforder);
            
            % Consolidate on-image and on-fixation responses (if they
            % responded during the fixation although they were only
            % supposed to respond during the image)
            onimagepresses = perforder(1:2:end);
            offimagepresses = perforder(2:2:end);
            % this balances response length if they stopped early
            if length(onimagepresses) > length(offimagepresses)
                offimagepresses = [offimagepresses; zeros(1,length(onimagepresses)-length(offimagepresses))];
            elseif length(onimagepresses) < length(offimagepresses)
                onimagepresses = [onimagepresses; repmat(MISS,length(offimagepresses)-length(onimagepresses))];
            end
            onimagepresses(offimagepresses==HIT)=HIT;
            onimagepresses(offimagepresses==FALSEALARM & onimagepresses==MISS)=FALSEALARM;
            perforder = onimagepresses;
            perforder = perforder(1:length(imtypeorder));
            
            
            % Here is a spot you can filter participant performance down
            % further
            % if ((sum(perforder==HIT) + sum(perforder==FALSEALARM)) > 4) && (sum(perforder(imtypeorder==VIGILANCE)==HIT) > sum(perforder(imtypeorder==VIGILANCE)==MISS))
            
            % Save their data in a structure with the orders of images they
            % saw
            subdata(subcount).imorder = imorder;
            subdata(subcount).imtypeorder = imtypeorder;
            subdata(subcount).perforder = perforder;
            
            % Calculate their performance metrics
            subdata(subcount).targets.hits = sum(perforder==HIT & imtypeorder==REPEAT);
            subdata(subcount).targets.misses = sum(perforder==MISS & imtypeorder==REPEAT);
            subdata(subcount).targets.falsealarms = sum(perforder==FALSEALARM & imtypeorder==TARGET);
            subdata(subcount).targets.correctrejections = sum(perforder==CORRECTREJECTION & imtypeorder==TARGET);
            subdata(subcount).fillers.hits = sum(perforder==HIT & imtypeorder==VIGILANCE);
            subdata(subcount).fillers.misses = sum(perforder==MISS & imtypeorder==VIGILANCE);
            subdata(subcount).fillers.falsealarms = sum(perforder==FALSEALARM & imtypeorder==FILLER);
            subdata(subcount).fillers.correctrejections = sum(perforder==CORRECTREJECTION & imtypeorder==FILLER);
            
            %% Also save the data in a structure organized by image.
            
            if subdata(subcount).fillers.misses < 45 % Participants can only miss 45 vigilance repeats (70%) at most
                for c = 1:length(imorder)
                    imfile = imorder{c};
                    if sum(ismember(imdictionary, imfile)) % If that image is already in the dictionary
                        % Then -- add in the new data from this participant
                        index = find(ismember(imdictionary, imfile));
                        imdata(index).suborder = [imdata(index).suborder {subdata(subcount).name}];
                        imdata(index).imtypeorder = [imdata(index).imtypeorder imtypeorder(c)];
                        imdata(index).perforder = [imdata(index).perforder perforder(c)];
                        
                        % Also increment the performance metrics
                        if perforder(c) == HIT && imtypeorder(c) == REPEAT
                            imdata(index).target.hits = imdata(index).target.hits + 1;
                        elseif perforder(c) == MISS && imtypeorder(c) == REPEAT
                            imdata(index).target.misses = imdata(index).target.misses + 1;
                        elseif perforder(c) == FALSEALARM && imtypeorder(c) == TARGET
                            imdata(index).target.falsealarms = imdata(index).target.falsealarms + 1;
                        elseif perforder(c) == CORRECTREJECTION && imtypeorder(c) == TARGET
                            imdata(index).target.correctrejections = imdata(index).target.correctrejections +1;
                        elseif perforder(c) == HIT && imtypeorder(c) == VIGILANCE
                            imdata(index).filler.hits = imdata(index).filler.hits + 1;
                        elseif perforder(c) == MISS && imtypeorder(c) == VIGILANCE
                            imdata(index).filler.misses = imdata(index).filler.misses + 1;
                        elseif perforder(c) == FALSEALARM && imtypeorder(c) == FILLER
                            imdata(index).filler.falsealarms = imdata(index).filler.falsealarms + 1;
                        elseif perforder(c) == CORRECTREJECTION && imtypeorder(c) == FILLER
                            imdata(index).filler.correctrejections = imdata(index).filler.correctrejections + 1;
                        end
                        
                    else % Otherwise -- this is an image we don't have data for yet, so add it to the dictionary
                        imdictionary{dicount} = imfile;
                        imdata(dicount).id = dicount;
                        imdata(dicount).name = imfile;
                        imdata(dicount).imtypeorder = imtypeorder(c);
                        imdata(dicount).suborder = subdata(subcount).name;
                        imdata(dicount).perforder = perforder(c);
                        
                        % Initialize performance metrics
                        imdata(dicount).target.hits = 0;
                        imdata(dicount).target.misses = 0;
                        imdata(dicount).target.falsealarms = 0;
                        imdata(dicount).target.correctrejections = 0;
                        imdata(dicount).filler.hits = 0;
                        imdata(dicount).filler.misses = 0;
                        imdata(dicount).filler.falsealarms = 0;
                        imdata(dicount).filler.correctrejections = 0;
                        
                        % now increment how they did on that first trial
                        if perforder(c) == HIT && imtypeorder(c) == REPEAT
                            imdata(dicount).target.hits = 1;
                        elseif perforder(c) == MISS && imtypeorder(c) == REPEAT
                            imdata(dicount).target.misses = 1;
                        elseif perforder(c) == FALSEALARM && imtypeorder(c) == TARGET
                            imdata(dicount).target.falsealarms = 1;
                        elseif perforder(c) == CORRECTREJECTION && imtypeorder(c) == TARGET
                            imdata(dicount).target.correctrejections = 1;
                        elseif perforder(c) == HIT && imtypeorder(c) == VIGILANCE
                            imdata(dicount).filler.hits = 1;
                        elseif perforder(c) == MISS && imtypeorder(c) == VIGILANCE
                            imdata(dicount).filler.misses = 1;
                        elseif perforder(c) == FALSEALARM && imtypeorder(c) == FILLER
                            imdata(dicount).filler.falsealarms = 1;
                        elseif perforder(c) == CORRECTREJECTION && imtypeorder(c) == FILLER
                            imdata(dicount).filler.correctrejections = 1;
                        end
                        dicount = dicount+1;
                    end
                end
                
                subcount = subcount + 1;
            end
        end
    end
end

% Save all of this!
save(matsavefile,'imdata','subdata');

%% Calculate the by-image metrics

fid = fopen(memorabilityscoresCSV,'w');
fprintf(fid, 'filename,hr,far\n');
for c = 1:length(imdata)
    hits(c) = imdata(c).target.hits;
    misses(c) = imdata(c).target.misses;
    fas(c) = imdata(c).target.falsealarms;
    crs(c) = imdata(c).target.correctrejections;
    hr(c) = imdata(c).target.hits / (imdata(c).target.hits + imdata(c).target.misses);
    far(c) = imdata(c).target.falsealarms / (imdata(c).target.falsealarms + imdata(c).target.correctrejections);
    cr(c) = hr(c) - far(c);
    dictionary{c} = imdata(c).name;
    fprintf(fid, '%s,%4.3f,%4.3f\n', dictionary{c}, hr(c), far(c));
end
fclose(fid);
save(memorabilityscoresMAT,'hits','misses','fas','crs','hr','far','cr','dictionary');

