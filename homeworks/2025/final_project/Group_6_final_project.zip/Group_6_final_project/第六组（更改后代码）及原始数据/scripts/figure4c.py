import numpy as np           
import matplotlib.pyplot as plt
import seaborn as sns
from mpl_toolkits.mplot3d import Axes3D
from matplotlib import cm
import matplotlib.colors as mcol
import matplotlib.cm as cm
import matplotlib.font_manager as fm
import matplotlib as mpl


######################## PLOTTING DEFAULTS ########################

#fonts
prop_tick = fm.FontProperties(fname="/Library/Fonts/Microsoft/Arial.ttf",size=20)
prop_label = fm.FontProperties(fname="/Library/Fonts/Microsoft/Arial.ttf",size=24)
mpl.rcParams['pdf.fonttype'] = 42 #save as editable text

#axes
mpl.rcParams['axes.linewidth'] = 0
mpl.rcParams['xtick.major.size'] = 0
mpl.rcParams['xtick.major.width'] = 0
mpl.rcParams['ytick.major.size'] = 0
mpl.rcParams['ytick.major.width'] = 0


#colors
cmap5 = mcol.LinearSegmentedColormap.from_list("MyCmapName",[[217/255.,217/255.,217/255.],[162/255.,39/255.,69/255.]])
cmap6 = mcol.LinearSegmentedColormap.from_list("MyCmapName",[[207/255.,209/255.,213/255.],[142/255.,45/255.,81/255.]])
cmap7 = mcol.LinearSegmentedColormap.from_list("MyCmapName",[[190/255.,197/255.,207/255.],[127/255.,50/255.,91/255.]])
cmap8 = mcol.LinearSegmentedColormap.from_list("MyCmapName",[[168/255.,180/255.,198/255.],[116/255.,54/255.,97/255.]])
cmap9 = mcol.LinearSegmentedColormap.from_list("MyCmapName",[[135/255.,156/255.,186/255.],[108/255.,57/255.,102/255.]])
cmap10 = mcol.LinearSegmentedColormap.from_list("MyCmapName",[[91/255.,122/255.,169/255.],[102/255.,58/255.,106/255.]])
cmap11 = mcol.LinearSegmentedColormap.from_list("MyCmapName",[[35/255.,80/255.,147/255.],[99/255.,60/255.,108/255.]])


######################## MIXED EFFECTS MODELING RESULTS ########################

x = np.linspace(-10,10,8)
y = np.linspace(-10,10,8)
X,Y = np.meshgrid(x,y)

#model parameters
intercept = 0
beta_a = .14
beta_m = .29

Z=np.exp(intercept+beta_m*X + beta_a*Y)/(1+np.exp(intercept+beta_m*X+beta_a*Y))


############## GENERATE PLOTS ##############

fig = plt.figure(figsize=(7,12))
ax = fig.gca(projection='3d')

#draw surfaces
surf = ax.plot_surface(X[:2,:8], Y[:2,:8], Z[:2,:8],cmap=cmap5,linewidth=1,edgecolor='k',antialiased=True)
surf = ax.plot_surface(X[1:3,:8], Y[1:3,:8], Z[1:3,:8],cmap=cmap6,linewidth=1,edgecolor='k',antialiased=True)
surf = ax.plot_surface(X[2:4,:8], Y[2:4,:8], Z[2:4,:8],cmap=cmap7,linewidth=1,edgecolor='k',antialiased=True)
surf = ax.plot_surface(X[3:5,:8], Y[3:5,:8], Z[3:5,:8],cmap=cmap8,linewidth=1,edgecolor='k',antialiased=True)
surf = ax.plot_surface(X[4:6,:8], Y[4:6,:8], Z[4:6,:8],cmap=cmap9,linewidth=1,edgecolor='k',antialiased=True)
surf = ax.plot_surface(X[5:7,:8], Y[5:7,:8], Z[5:7,:8],cmap=cmap10,linewidth=1,edgecolor='k',antialiased=True)
surf = ax.plot_surface(X[6:,:8], Y[6:,:8], Z[6:,:8],cmap=cmap11,linewidth=1,edgecolor='k',antialiased=True)


#ticks & tick labels
ax.set_xticks([-10,-5,0,5,10])
ax.set_xticklabels([-10,-5,0,5,10],va='top',ha='right',color=[77/255.,77/255.,77/255.],fontproperties=prop_tick)
ax.set_yticks([-10,-5,0,5,10])
ax.set_yticklabels([-10,-5,0,5,10],rotation=-15,ha='left',va='center',color=[77/255.,77/255.,77/255.],FontProperties=prop_tick)
ax.set_zticks([0,1])
ax.set_zticklabels(["Forgotten","Remembered"],ha='left',va='center',color=[77/255.,77/255.,77/255.],fontproperties=prop_tick,position=(0,10))
ax.tick_params(axis='x', which='major', pad=-3)
ax.tick_params(axis='y', which='major', pad=-3)
ax.tick_params(axis='z', which='major', pad=-1)

# axes labels
ax.set_xlabel("Memorability",ha='right',fontproperties=prop_label,labelpad=10)
ax.set_ylabel("Sustained Attention",va='baseline',horizontalalignment='left',fontproperties=prop_label,labelpad=20)
ax.set_zlabel("Subsequent Memory",rotation=90,ha='left',fontproperties=prop_label,labelpad=30)

#axes limits
ax.set_xlim([-10,10])
ax.set_ylim([-10,10])
ax.set_zlim3d([0,1])

#background colors
ax.w_xaxis.set_pane_color((1.0, 1.0, 1.0, 1.0))
ax.w_yaxis.set_pane_color((1.0, 1.0, 1.0, 1.0))
ax.w_zaxis.set_pane_color((1.0, 1.0, 1.0, 1.0))

#defaults
#ax.azim -60
#ax.elev 30
ax.view_init(elev=30,azim=-60)
ax.dist = 10

plt.show(block=False)
fig.savefig('../figures/figure4c.pdf', bbox_inches="tight")