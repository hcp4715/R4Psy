library(tidyverse)
library(plotrix)
library(ggpubr)
library(patchwork)
#library(showtext)
library(gridExtra)

rm(list=ls())


######################## Load & filter data ######################## 
# read in memorablity data
mem <- read.csv("./data_expt1/memscores-30-Jun-2021.csv")%>%
  rename(imagename=filename)%>%
  mutate(cr=hr-far)

# read in attention data and make distinct subject numbers
att_exp2 <- read.csv("./data_expt2/Expt2_attnmem.csv")%>%
  mutate(exp="exp2")
att_exp2$subject_num = att_exp2$subject_num+100

att_exp3 <- read.csv("./data_expt3/Expt3_attnmem.csv")%>%
  mutate(exp="exp3")
att_exp3$subject_num = att_exp3$subject_num+200

# join attention data, keep only infrequent category trials, exclude subjects for poor attention task performance
all_att <- rbind(att_exp3,att_exp2)%>%
  filter( subject_num!=125 & subject_num!=226)%>%
  rename(imagename=image_name)

is.nan.data.frame <- function(x)
  do.call(cbind, lapply(x, is.nan))

all_att[is.nan(all_att)] <- NA
all_att$subject_num <- factor(all_att$subject_num)
all_att$exp <- factor(all_att$exp)
all_att$attn_acc <- factor(all_att$attn_acc)

# add image category to memorability data
mem2 <- merge(mem, all_att[, c("image_categname", "imagename")], by ="imagename", all = TRUE)
mem2 <- mem2[!duplicated(mem2$imagename),]

# filter to keep only infrequent trials
all_att <- all_att %>% filter((subject_infreq_categ == "indoor" & image_categname == "indoor")|(subject_infreq_categ == "outdoor" & image_categname == "outdoor"))

#merge memorability and attention data
all_att_memorab <- merge(all_att,mem, by ="imagename")
all_att_memorab <- all_att_memorab %>%
  mutate(mem_remembered_thr4= ifelse(all_att_memorab$mem_rating == 4, 1, 0))


######################## Pretrial RT predicts attention ######################## 
all_att_memorab$exp <- gsub('exp', 'Experiment ', all_att_memorab$exp)
mean_pretrial_rts <- all_att_memorab %>% 
  group_by(exp,subject_num,attn_acc) %>% 
  summarise(attn_pretrial_rtsresid = mean(attn_pretrial_rtsresid, na.rm = TRUE))%>%
  unite(type,attn_acc,exp, remove=FALSE)
mean_pretrial_rts$type <- factor(mean_pretrial_rts$type,levels = c("0_exp2", "1_exp2", "0_exp3", "1_exp3"))

# Sort by exp, then attn_acc, then subject_num
mean_pretrial_rts          <- mean_pretrial_rts[order(mean_pretrial_rts$exp, mean_pretrial_rts$attn_acc, mean_pretrial_rts$subject_num), ]
mean_pretrial_rts$attn_acc <- as.factor(mean_pretrial_rts$attn_acc)


######################## Memorability consistency  ########################
# load memorability consistency outputs from matlab
x <- read.csv("./data_expt1/consistencyfiguredata-16-Jul-2021_flipped.csv",header=TRUE)
df1 = data.frame(x)
df1$image <- c(1:1100)


############################ Generate figures ############################  
# colors
r_dark = rgb(162/255, 39/255, 69/255)
r_light = rgb(226/255, 108/255, 132/255)
b_dark = rgb(35/255, 80/255, 147/255)
b_light = rgb(90/255, 148/255, 206/255)
p_dark = rgb(99/255, 60/255, 108/255)
p_light = rgb(158/255, 128/255, 169/255)

# themes
fig3a_theme <- theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
                     panel.background = element_blank(), legend.position = "left", 
                     axis.line = element_line(colour = "gray") ,
                     axis.title.x = element_text(size = 24, margin=margin(15,0,0,0)),
                     axis.ticks = element_blank(),
                     axis.title.y = element_text(size = 24, margin=margin(0,12,0,0)),
                     axis.text = element_text(size = 20))

fig3b_theme <- theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
                     panel.background = element_blank(), legend.position = "none", 
                     axis.line = element_line(colour = "grey") ,
                     axis.title.x = element_blank(),
                     axis.ticks = element_blank(),
                     axis.title.y = element_text(size = 24, margin=margin(0,12,0,0)),
                     axis.text = element_text(size = 20),
                     strip.background = element_blank(),
                     strip.text.x = element_text(size = 24, margin=margin(15,0,0,0)),
                     strip.placement = "outside",
                     panel.spacing.x=unit(1, "lines"))


# Memorability plot
memorability_plot <- ggplot() +
  geom_line(data=df1, aes(x = image,y = chance),size=.75,color="grey") +
  geom_line(data=df1, aes(x = image,y = group1),size=.75,color=r_dark) +
  geom_line(data=df1, aes(x = image,y = group2),size=.75,color=r_light) +
  labs(
    x= "Image (#)",
    y= "Memorability (CR)") +
  annotate("text", x=800, y=.95, label= "Group 1", size=7,color=r_dark,hjust=0) +
  annotate("text", x=800, y=.87, label= "Group 2",size=7,color=r_light,hjust=0) +
  annotate("text", x=800, y=.79, label= "Chance",size=7,color="grey",hjust=0) +
  ylim(0,1) +
  scale_x_continuous(breaks=c(0,250,500,750,1000), limits=c(0,1100)) +
  coord_cartesian(clip = "off") + 
  fig3a_theme


# Pretrial RT plot
rt_acc_plot<-ggplot(data=mean_pretrial_rts, aes(x=attn_acc, y=attn_pretrial_rtsresid, fill=attn_acc))+
  facet_wrap(~exp, scales = "fixed", strip.position = "bottom") +
  geom_bar(colour="black", alpha=0.7, stat="summary", fun = "mean", position = position_dodge(.75), width=.5) +
  geom_point(size=2, stroke = 0,position = position_dodge(width=0.75),color="black",alpha=.15) + 
  geom_line(aes(color=attn_acc, group=subject_num), color="black",alpha=.15) +
  geom_abline(slope = 0,intercept = 0, color="grey") +
  aes(fill=exp) +
  scale_fill_manual(values = c(b_dark,b_light)) +
  scale_x_discrete(labels=c("Lapse", "Correct")) +
  ylim(-.2,.2)+
  labs(y="Pre-trial Attentional State\n(Detrended RT, s)") +
  coord_cartesian(clip = "off") + 
  fig3b_theme



############# SAVE FIGURE #############
#showtext_auto()

pdf(file = "figures/figure3.pdf",   
    width = 14, 
    height = 5) 

figure3<- ggarrange(NULL,NULL,NULL,memorability_plot,NULL,rt_acc_plot,
                    widths = c(1.2,.1,1,1.2,.1,1),
                    heights = c(.11,1),
                    labels = c("a","b"),
                    label.x = 0,
                    label.y = 1,
                    font.label = list(color="Black",size = 32),
                    ncol = 3, nrow = 2)
figure3

dev.off()
#showtext_auto(FALSE)
