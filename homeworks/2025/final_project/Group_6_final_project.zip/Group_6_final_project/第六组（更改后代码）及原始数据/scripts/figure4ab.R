library(tidyverse)
library(lme4)
library(optimx)
library(mousetrap)
library(plotrix)
library(ggpubr)
library(patchwork)
#library(showtext)
library(gridExtra)

rm(list=ls())

######################## Load & filter data ######################## 
# read in memorablity data
mem <- read.csv("./data_expt1/memscores-30-Jun-2021.csv")%>%
  rename(imagename=filename)%>%
  mutate(cr=hr-far)

# read in attention data and make distinct subject numbers
att_exp2 <- read.csv("./data_expt2/Expt2_attnmem.csv")%>%
  mutate(exp="exp2")
att_exp2$subject_num = att_exp2$subject_num+100

att_exp3 <- read.csv("./data_expt3/Expt3_attnmem.csv")%>%
  mutate(exp="exp3")
att_exp3$subject_num = att_exp3$subject_num+200

# join attention data, keep only infrequent category trials, exclude subjects for poor attention task performance
all_att <- rbind(att_exp3,att_exp2)%>%
  filter( subject_num!=125 & subject_num!=226)%>%
  rename(imagename=image_name)

is.nan.data.frame <- function(x)
  do.call(cbind, lapply(x, is.nan))

all_att[is.nan(all_att)] <- NA
all_att$subject_num <- factor(all_att$subject_num)
all_att$exp <- factor(all_att$exp)
all_att$attn_acc <- factor(all_att$attn_acc)

# add image category to memorability data
mem2 <- merge(mem, all_att[, c("image_categname", "imagename")], by ="imagename", all = TRUE)
mem2 <- mem2[!duplicated(mem2$imagename),]

# filter to keep only infrequent trials
all_att <- all_att %>% filter((subject_infreq_categ == "indoor" & image_categname == "indoor")|(subject_infreq_categ == "outdoor" & image_categname == "outdoor"))

#merge memorability and attention data
all_att_memorab <- merge(all_att,mem, by ="imagename")
all_att_memorab <- all_att_memorab %>%
  mutate(mem_remembered_thr4= ifelse(all_att_memorab$mem_rating == 4, 1, 0))


######################## Mixed effects models ######################## 
attmem_drop_na<-all_att_memorab%>%
  dplyr::select(mem_remembered_thr4, cr,attn_pretrial_rtsresid, subject_num, exp, image_num,attn_trialnum)%>%
  drop_na()
attmem_drop_na$subject_num <- factor(attmem_drop_na$subject_num)
attmem_drop_na <- scale_within(attmem_drop_na, variables=c("attn_pretrial_rtsresid", "cr"), within="subject_num",prefix="scale_")
attmem_drop_na_exp2 <- attmem_drop_na %>%
  filter(exp=="exp2")
attmem_drop_na_exp3 <- attmem_drop_na %>%
  filter(exp=="exp3")

#Separate model: cr
regression_cr_both   <- glmer(mem_remembered_thr4 ~ scale_cr + (1 | exp/subject_num), data=attmem_drop_na, family = binomial(link = "logit"), control = glmerControl(optimizer ='optimx', optCtrl=list(method='L-BFGS-B')))

#Separate model: attn
regression_attn_both <- glmer(mem_remembered_thr4 ~ scale_attn_pretrial_rtsresid + (1 | exp/subject_num), data=attmem_drop_na, family = binomial(link = "logit"), control = glmerControl(optimizer ='optimx', optCtrl=list(method='L-BFGS-B')))

#Joint model
regression_joint_full <- glmer(mem_remembered_thr4 ~ scale_attn_pretrial_rtsresid+scale_cr + (1 | exp/subject_num), data=attmem_drop_na,family = binomial(link = "logit"), control = glmerControl(optimizer ='optimx', optCtrl=list(method='L-BFGS-B')))

#Generate model predictions for each trial
attmem_drop_na$pred_cr    <- fitted(regression_cr_both, type="response")
attmem_drop_na$pred_attn  <- fitted(regression_attn_both, type="response")
attmem_drop_na$pred_joint <- fitted(regression_joint_full, type="response")


############################ Generate figures ############################  
# colors
r_dark = rgb(162/255, 39/255, 69/255)
r_light = rgb(226/255, 108/255, 132/255)
b_dark = rgb(35/255, 80/255, 147/255)
b_light = rgb(90/255, 148/255, 206/255)
p_dark = rgb(99/255, 60/255, 108/255)
p_light = rgb(158/255, 128/255, 169/255)

fig_theme <- theme(panel.grid.major = element_blank(), 
                   panel.grid.minor = element_blank(),
                   panel.background = element_blank(), 
                   axis.line = element_line(colour = "grey"),
                   legend.position="none", 
                   axis.ticks = element_blank(), 
                   axis.title.x = element_text(size = 24, margin=margin(12,0,0,0)),
                   axis.title.y = element_text(size = 24, margin=margin(0,12,0,0)),
                   axis.text = element_text(size = 20))
  
mem_plot <- ggplot(attmem_drop_na, aes(x=scale_cr, y=mem_remembered_thr4)) +
  geom_line(aes(y=pred_cr,group=subject_num,colour=exp), stat = "smooth", se = FALSE, method = "glm", method.args = list(family = "binomial"),size=.7,alpha=.6)+
  scale_color_manual(values=c(r_dark,r_light)) +
  geom_smooth(aes(y=pred_cr),se = FALSE, method = "glm", method.args = list(family = "binomial"),color="black",size=1.4) +
  ylim(0, 1) + 
  xlim(-4,4)+
  fig_theme + 
  labs(
    x= "Memorability (z-scored)",
    y= "Subsequent Memory"
  )+
  annotate("text", x=-2.0, y=.97, label= "Experiment 2", size=7,color=rgb(.4549, .0588, .19215))+
  annotate("text", x=-2.0, y=.89, label= "Experiment 3",size=7,color=rgb(.81176, .2470, .3451))

attn_plot <- ggplot(attmem_drop_na, aes(x=scale_attn_pretrial_rtsresid, y=mem_remembered_thr4)) +
  geom_line(aes(y=pred_attn,group=subject_num,colour=exp), stat = "smooth", se = FALSE, method = "glm", method.args = list(family = "binomial"),size=.7,alpha=.6)+
  scale_color_manual(values=c(b_dark,b_light)) +
  geom_smooth(aes(y=pred_attn),se = FALSE, method = "glm", method.args = list(family = "binomial"),color="black",size=1.4) +
  ylim(0, 1) + 
  xlim(-4,4)+
  fig_theme + 
  labs(
    x= "Sustained Attention (z-scored)",
    y= "Subsequent Memory"
  )+
  annotate("text", x=-2.0, y=.97, label= "Experiment 2", size=7,color=b_dark)+
  annotate("text", x=-2.0, y=.89, label= "Experiment 3",size=7,color=b_light)


############# SAVE FIGURE #############
#showtext_auto()

pdf(file = "figures/figure4ab.pdf",   
    width = 6, 
    height = 10) 

figure4ab <- ggarrange(NULL,NULL,NULL,NULL,mem_plot,NULL,NULL,NULL,NULL,NULL,attn_plot,NULL,
                    widths  = c(.085,1.1,.075),
                    heights = c(.05,1,.05,1),
                    labels = c("a","","","","","","b","","","","",""),
                    label.x = 0,
                    label.y = 1,
                    font.label = list(color="Black",size = 32),
                    ncol = 3, nrow = 4)
figure4ab

dev.off()
#showtext_auto(FALSE)
