% expt2_create_attnmem_csv.m
% 
% the goal of this code is to load the .mat files from experiment 3 and 
% print out the relevant data to analyze the influence of (1) memorability
% and (2) sustained attention on recognition memory
%
% code written by MdB 07/2021, data collected by SC


%% experimental details 

%subject information
all_subj = 1:37;
excluded_subj = [10,12,21];
all_subj = setdiff(all_subj,excluded_subj);

nsubj = numel(all_subj);
expt_dir = './../data_expt2/';
subjects_dir = [expt_dir 'subjects/'];

%experiment information
categs = {'outdoor','indoor'};

%%%%%%%%%% image information %%%%%%%%%%
stim_dir = './../stim/'; %directory where stimulus folders are saved

% outdoor images
dirList = dir([stim_dir  '/sunoutdoor550/*.jpg']);
imagenames_outdoor = {dirList.name};

%indoor images
dirList = dir([stim_dir '/sunindoor550/*.jpg']); 
imagenames_indoor = {dirList.name};

imagenames = {imagenames_outdoor,imagenames_indoor};


%% loop through the subjects 

T = table(); %create empty table

for isubj = 1:nsubj
    clearvars dat
    subject_num = all_subj(isubj);
    
    %%%%%%%%%% load attention data %%%%%%%%%%
    fn = deblank(ls([subjects_dir num2str(subject_num) '/attndata_*']));
    load(fn); %this loads a structure attnData
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %extract category information from  attnData file
    categ_freq = mode(attnData.categs);
    categ_infreq = rem(categ_freq,2)+1;
    categ_infreq_name = categs(categ_infreq);
    
    %%%%%%%%%% load memory data %%%%%%%%%%
    fn = deblank(ls([subjects_dir num2str(subject_num) '/memdata_*']));
    load(fn) %this loads a struct memData
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %extract information from  memData file
    i_old_trials = find(memData.memCategs<3); %1 and 2 were coded as old trials
    nimages = numel(i_old_trials); %number of infrequent images

    %extract information specific to this subject
    dat.subject_num = repmat(subject_num,nimages,1); %subject number (3-27
    dat.subject_infreq_categ = repmat(categ_infreq_name,nimages,1); %which category was infrequent (outdoor or indoor)
    
    %extract relevant information from recognition memory phase 
    dat.mem_rating = (memData.rating(i_old_trials))'; %rating for this image
    dat.mem_trialnum = (i_old_trials)'; %trial order from recognition memory phase
    dat.mem_rts = (memData.rts(i_old_trials))';
    
    %extract relevant information from attention phase
    %Note: this also reorganizes trials in the memory phase order
    dat.attn_trialnum = (memData.attOrder(i_old_trials))'; 
    dat.image_num = attnData.images(dat.attn_trialnum)';
    dat.image_categ = attnData.categs(dat.attn_trialnum)';
    dat.image_categname = categs(attnData.categs(dat.attn_trialnum))';
    dat.attn_acc = attnData.accs(dat.attn_trialnum)';
    dat.attn_rts = attnData.rts(dat.attn_trialnum)';
    
    %calculate detrended RT, after subtracting linear trend 
    rts_est = nan(attnData.trialsPerRun);
    rts_resid = nan(attnData.trialsPerRun);
    idx = 1:attnData.trialsPerRun;
    linfit = polyfit(idx(~isnan(attnData.rts)),attnData.rts(~isnan(attnData.rts)),1);
    rts_est = linfit(1).*idx+linfit(2);
    rts_resid = attnData.rts-rts_est;
    
    % attention results
    dat.attn_rtsresid_3prev = nan(nimages,1);
    for itrial = 1:nimages
        
        %when did this trial appear in the attention phase
        i = dat.attn_trialnum(itrial);
        
        %what is the name of this image
        dat.image_name{itrial,1} = imagenames{attnData.categs(i)}{attnData.images(i)};
        
        %calcuate the pretrial RTs, after detrending
        i_pretrial = (i-3):(i-1);
        i_pretrial = i_pretrial(i_pretrial>0); %exclude any negative indices
        if numel(i_pretrial)>0
            dat.attn_pretrial_rtsresid(itrial,1) = nanmean(rts_resid(i_pretrial));
        end
    
    end

    %convert to table
    subj_table = struct2table(dat);
    
    %rearrange column order... couldn't find a better way to do that
    subj_table = subj_table(:,{'subject_num','subject_infreq_categ',...
        'image_name','image_num','image_categ','image_categname',...
        'mem_rating','mem_trialnum','mem_rts',...
        'attn_pretrial_rtsresid','attn_acc','attn_trialnum'});
    
    T = [T; subj_table];
end

%% save data from all subjects

fn_save = [expt_dir 'expt2_attnmem.csv'];
writetable(T,fn_save)