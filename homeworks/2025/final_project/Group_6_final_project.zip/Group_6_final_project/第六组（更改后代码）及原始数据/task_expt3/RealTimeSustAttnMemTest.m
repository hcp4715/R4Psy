function [memData] = RealTimeSustAttnMemTest(subjectNum,subjectName,runNum,debug)
% function [memData] = SustAttnMemTest(subjectNum,subjectName,runNum,debug)
%
% Recognition memory test for scenes 
%
%
% REQUIRED INPUTS:
% - subjectNum:  participant number [any integer]
% - subjectName: participant initials [any string]
% - runNum:      run number [any integer]
% - debug:       whether debugging [1 if debugging/0 if not]
%
% OUTPUTS
% - blockData:   structure of experiment design and behavioral responses
%
% Written by:  Megan deBettencourt
% Version: 1.0
% Last modified: April 2014

%% check inputs

%check that there is a sufficient number of inputs
if nargin < 4;error('4 inputs are required: subjectNum, subjectName, runNum, debug');end

%check that inputs are of the right format
if ~isnumeric(subjectNum);error('subjectNum must be a number');end
if ~ischar(subjectName);error('subjectName must be a string');end
if ~isnumeric(runNum);error('runNum must be a number');end
if ((debug~=1) && (debug~=0));error('debug must be either 1 (if debugging) or 0 (if not)');end

%% Boilerplate

%make subject data folder, if it does not exist already
dataHeader = ['rtdata/' num2str(subjectNum)];
if ~exist(dataHeader);mkdir(dataHeader);end %#ok<EXIST>

%MdB write a check that the subject does not already exist 

%random seed
seed = sum(100*clock);
ver = version;
if strfind(ver,'2013')
    RandStream.setGlobalStream(RandStream('mt19937ar','seed',seed));
else
    RandStream.setDefaultStream(RandStream('mt19937ar','seed',seed)); %#ok<SETRS>
end

%check whether debugging
if (debug) 
    Screen('Preference', 'SkipSyncTests', 1);
else
    ListenChar(2);  %prevent command window output
    HideCursor;     %hide mouse cursor    
end
    
%initialize system time calls
GetSecs;

%% Experimental Parameters

% display parameters
textColor = 0;      % black text
textFont = 'Arial';
textSize = 14;
textSpacing = 25;   
fixColor = 0;       % black fixation dot before response
respColor = 255;    % white fixation dot after response
backColor = 127;    % gray background
imageSize = 256;    % assumed square 
fixationSize = 4;   % pixels
progWidth = 400;    % image loading progress bar width
progHeight = 20;    % image loading progress bar height
ScreenResX = 1600;  % TO BE CHANGED - check the resolution of the running room computers!!!
ScreenResY = 900;   % TO BE CHANGED - check the resolution of the running room computers!

memStimDur = 10;     %secs
ITI = .5;           %secs
IBI = 2;            %secs

nSubCategs=2;
OUTDOOR=1;
INDOOR=2;


%% Response Mapping and Counterbalancing

% skyra: use current design button box (keys 1,2,3,4)
ONE = KbName('1!');
TWO = KbName('2@');
THREE = KbName('3#');
FOUR = KbName('4$');

DEVICE = -1;

starttaskinstruct = 'Please hit spacebar to start task';

%% Initialize Screens

screenNumbers = Screen('Screens');

if debug
    %show on first screen
    screenNum = 0;
    
    %draw on only top left quarter of screen
    %[screenX screenY] = Screen('WindowSize',screenNum);
    screenX = 500;
    screenY = 500;
else
    %show on last screen (e.g. second monitor)
    screenNum = screenNumbers(end);
    
    %draw on full screen
    [screenX screenY] = Screen('WindowSize',screenNum);
    
    %to ensure that the images are standardized (they take up the same degrees of the visual field) for all subjects
    if (screenX ~= ScreenResX) || (screenY ~= ScreenResY)
        fprintf('The screen dimensions may be incorrect. For screenNum = %d,screenX = %d (not 1152) and screenY = %d (not 864)',screenNum, screenX, screenY);
    end
end

%create main window
mainWindow = Screen(screenNum,'OpenWindow',backColor,[0 0 screenX screenY]);

% details of main window
centerX = screenX/2; centerY = screenY/2;
Screen(mainWindow,'TextFont',textFont);
Screen(mainWindow,'TextSize',textSize);

% placeholder for images
imageRect = [0,0,imageSize,imageSize];

% position of images
centerRect = [centerX-imageSize/2,centerY-imageSize/2,centerX+imageSize/2,centerY+imageSize/2];

% position of fixation dot
fixDotRect = [centerX-fixationSize,centerY-fixationSize,centerX+fixationSize,centerY+fixationSize];

% image loading progress bar
progRect = [centerX-progWidth/2,centerY-progHeight/2,centerX+progWidth/2,centerY+progHeight/2];

%% Load Images

cd instructimages;
for categ=1:nSubCategs
    
    % move into the right folder
    if (categ == OUTDOOR)
        cd outdoor;
    elseif (categ == INDOOR)
        cd indoor;
    else
        error('Impossible category!');
    end
    
    % get filenames
    dirList{categ} = dir;  %#ok<AGROW>
    dirList{categ} = dirList{categ}(3:end); %#ok<AGROW> %skip . & ..
    if (~isempty(dirList{categ}))
        if (strcmp(dirList{categ}(1).name,'.DS_Store')==1)
            dirList{categ} = dirList{categ}(2:end);  %#ok<AGROW>
        end
        
        if (strcmp(dirList{categ}(end).name,'Thumbs.db')==1)
            dirList{categ} = dirList{categ}(1:(end-1));  %#ok<AGROW>
        end
        
        instructNumImages(categ) = length(dirList{categ}); %#ok<AGROW>
        
        if (instructNumImages(categ)>0)
            
            % get images
            for img=1:instructNumImages(categ)
                
                % update progress bar
                Screen('FrameRect',mainWindow,0,progRect,10);
                Screen('FillRect',mainWindow,0,progRect);
                Screen('FillRect',mainWindow,[255 0 0],progRect-[0 0 round((1-img/instructNumImages(categ))*progWidth) 0]);
                Screen('Flip',mainWindow);
                
                % read images
                instructImages{categ,img} = imread(dirList{categ}(img).name);  %#ok<AGROW>
            end
            
            % randomize order of images in each run
            instructImageShuffle{categ} = randperm(instructNumImages(categ)); %#ok<AGROW>
            cd ..;
        end
    else
        error('Need at least one image per directory!');
    end
end
cd ..;
Screen('Flip',mainWindow);


cd images;
for categ=1:nSubCategs
    
    % move into the right folder
    if (categ == OUTDOOR)
        cd sunoutdoor550;
    elseif (categ == INDOOR)
        cd sunindoor550;
    else
        error('Impossible category!');
    end
    
    % get filenames
    dirList{categ} = dir;  %#ok<AGROW>
    dirList{categ} = dirList{categ}(3:end); %#ok<AGROW> %skip . & ..
    if (~isempty(dirList{categ}))
        if (strcmp(dirList{categ}(1).name,'.DS_Store')==1)
            dirList{categ} = dirList{categ}(2:end);  %#ok<AGROW>
        end
        
        if (strcmp(dirList{categ}(end).name,'Thumbs.db')==1)
            dirList{categ} = dirList{categ}(1:(end-1));  %#ok<AGROW>
        end
        
        numImages(categ) = length(dirList{categ}); %#ok<AGROW>
        
        %numImages(categ) = 200;
        
        if (numImages(categ)>0)
            
            % get images
            for img=1:numImages(categ)
                
                % update progress bar
                Screen('FrameRect',mainWindow,0,progRect,10);
                Screen('FillRect',mainWindow,0,progRect);
                Screen('FillRect',mainWindow,[255 0 0],progRect-[0 0 round((1-img/numImages(categ))*progWidth) 0]);
                Screen('Flip',mainWindow);
                
                % read images
                imageNames{categ,img} = dirList{categ}(img).name;
                images{categ,img} = imread(dirList{categ}(img).name);  %#ok<AGROW>
            end
            
            % randomize order of images in each run
            imageShuffle{categ} = randperm(numImages(categ)); %#ok<AGROW>
            cd ..;
        end
    else
        error('Need at least one image per directory!');
    end
end
cd ..;
Screen('Flip',mainWindow);

cd images
for level = 1:5
    confRate{level} = imread(['conf/conf_rating_' num2str(level) '.jpg']);
    conf_textures{level} = Screen('MakeTexture',mainWindow,confRate{level});
    
    if level == 1
        confSize = size(confRate{1});
        confRect = [0 0 confSize(2) confSize(1)];
        
        distConfRect = CenterRect(confRect,[0 0 screenX screenY]) + [0 200 0 200];%lower part
    end%if level
end%for level
cd ..

%%

%load blockdata file
%cd(dataHeader);
load(deblank(ls([dataHeader '/blockdata_' num2str(runNum) '_*'])),'blockData');
%cd ../..

%%

if mod(subjectNum,2)==1
    goCateg=1;
    nogoCateg=2;
    sustAttnGoLocs = find(blockData.categs==goCateg);
    sustAttnGoImages = blockData.images(sustAttnGoLocs);
    sustAttnNoGoLocs = find(blockData.categs==nogoCateg);
    sustAttnNoGoImages = blockData.images(sustAttnNoGoLocs);
else
    goCateg=2;
    nogoCateg=1;
    sustAttnGoLocs = find(blockData.categs==goCateg);
    sustAttnGoImages = blockData.images(sustAttnGoLocs);
    sustAttnNoGoLocs = find(blockData.categs==nogoCateg);
    sustAttnNoGoImages = blockData.images(sustAttnNoGoLocs);
end

nMemCategs = 4;
goTargets = 1;
goLures = 3;
nogoTargets = 2;
nogoLures = 4;

for i = 1:ceil(blockData.trialsPerBlock/100)
    goLocsChunk{i} = (find((sustAttnGoLocs>((i-1)*100))&(sustAttnGoLocs<((i-1)*100+101))));
    goLocsShuffle{i} = Shuffle(goLocsChunk{i});
    goLocsSelect(i,:) = goLocsShuffle{i}(1:10);
end

memImageShuffle{goTargets} = sustAttnGoImages(Shuffle(reshape(goLocsSelect,1,[])));
memImageShuffle{goLures} = imageShuffle{goCateg}(find(~ismember(imageShuffle{goCateg},sustAttnGoImages)));
memImageShuffle{nogoTargets} = sustAttnNoGoImages(randperm(numel(sustAttnNoGoImages)));
memImageShuffle{nogoLures} = imageShuffle{nogoCateg}(find(~ismember(imageShuffle{nogoCateg},sustAttnNoGoImages)));



memData.attCategs = Shuffle([goCateg*ones(1,100) nogoCateg*ones(1,2*numel(sustAttnNoGoLocs))]);
nTrials = numel(memData.attCategs);
memData.trial = 1:nTrials;

memData.memCategs(memData.attCategs==goCateg)=Shuffle([goTargets*ones(1,50) goLures*ones(1,50)]);
memData.memCategs(memData.attCategs==nogoCateg)=Shuffle([nogoTargets*ones(1,numel(sustAttnNoGoLocs)) nogoLures*ones(1,numel(sustAttnNoGoLocs))]);

memCategCounter = zeros(1,nMemCategs);
for iTrial = 1:nTrials
    % update image counters
    memCategCounter(memData.memCategs(iTrial)) = memCategCounter(memData.memCategs(iTrial))+1;
    
    % get current images
    memData.images(iTrial) = memImageShuffle{memData.memCategs(iTrial)}(memCategCounter(memData.memCategs(iTrial))); 
%    memData.imageName{iTrial} = imageNames{memData.memCategs(iTrial),memData.images(iTrial)};
        
    if sum(memData.images(iTrial)==blockData.images)==0
        memData.attOrder(iTrial) = NaN;
    elseif (sum(memData.images(iTrial)==blockData.images)>=1) && (memData.memCategs(iTrial) <=2)
        tempInds = find(blockData.images==memData.images(iTrial));
        tempCategs = memData.attCategs(iTrial);
        memData.attOrder(iTrial) = tempInds(memData.attCategs(iTrial)==blockData.categs(tempInds));
    else
        memData.attOrder(iTrial) = NaN;
    end
end
memData.rts = nan(1,nTrials);
memData.resps = nan(1,nTrials);
memData.rating = nan(1,nTrials);
memData.accs = nan(1,nTrials);


%% Task Instructions

% clear screen
Screen(mainWindow,'FillRect',backColor);
Screen('Flip',mainWindow);
FlushEvents('keyDown');

% show instructions
welcomeInstruct = {'In part 2, we will be testing your memory for all of the photos that you just saw',...
    'This is the most critical part of the experiment, so please try your absolute best',...
    ' ',...
    'You will be shown images on the screen. Your task will be to report whether you remember seeing the image',...
    ['If you remember it very strongly press the ' KbName(FOUR) ' key'],...
    ['If you remember it only a bit press the ' KbName(THREE) ' key'],...
    ['If you don''t think you remember seeing it press the ' KbName(TWO) ' key'],...
    ['If you are sure you didn''t see it in part 1 press the ' KbName(ONE) ' key'],...
    ' ','Press all keys with your index finger of your right hand',...
    'And please try to use all the keys for your responses',...
    ' ','You will have as much time as needed to respond to each image.',...
    ' ','Hit spacebar to start task'};
for instruct=1:length(welcomeInstruct)
    tempBounds = Screen('TextBounds',mainWindow,welcomeInstruct{instruct});
    Screen('drawtext',mainWindow,welcomeInstruct{instruct},centerX-tempBounds(3)/2,centerY-tempBounds(4)/5+textSpacing*(instruct-4),textColor);
    clear tempBounds;
end
Screen('Flip',mainWindow);

% wait for experimenter to advance with space bar
FlushEvents('keyDown');
while KbCheck; end 
[~, ~, keyCode] = KbCheck(-1); % -1 checks all keyboards
while ~keyCode(KbName('space'))
    [~, ~, keyCode] = KbCheck(-1);
end
Screen(mainWindow,'FillRect',backColor);
Screen('Flip',mainWindow);


% %% practice trials
% 
% iTrial = 1;
% imageTex = Screen('MakeTexture',mainWindow,instructImages{OUTDOOR,1});
% Screen('FillRect',mainWindow,backColor);
% Screen('DrawTexture',mainWindow,imageTex,imageRect,centerRect);
% Screen(mainWindow,'FillOval',fixColor,fixDotRect);
% trialOnsets(iTrial) = Screen('Flip',mainWindow);
% rts(iTrial) = NaN;
% resps(iTrial) = NaN;
% while KbCheck; end
% while isnan(resps(iTrial))
%     % check for responses if none received yet
%     if isnan(blockData.rts(iTrial))
%         [keyIsDown, secs, keyCode] = KbCheck(DEVICE); % -1 checks all keyboards
%         if keyIsDown
%             if (keyCode(LEFT)) %|| keyCode(RIGHT))
%                 rts(iTrial) = secs-trialOnsets(iTrial);
%                 resps(iTrial) = find(keyCode,1);
%                 Screen('FillRect',mainWindow,backColor);
%                 Screen('DrawTexture',mainWindow,imageTex,imageRect,centerRect);
%                 Screen(mainWindow,'FillOval',respColor,fixDotRect);
%                 Screen('Flip',mainWindow);
%             end
%         end
%     end
% end


%% Output Files Setup

if subjectNum
    % open and set-up output file
    dataFile = fopen([dataHeader '/behavior.txt'],'a');
    fprintf(dataFile,'\n*********************************************\n');
    fprintf(dataFile,'* Sustained Attention and Recognition Memory Experiment - Memory Test v.1.0\n');
    fprintf(dataFile,['* Date/Time: ' datestr(now,0) '\n']);
    fprintf(dataFile,['* Seed: ' num2str(seed) '\n']);
    fprintf(dataFile,['* Subject Number: ' num2str(subjectNum) '\n']);
    fprintf(dataFile,['* Subject Name: ' subjectName '\n']);
    fprintf(dataFile,['* Run Number: ' num2str(runNum) '\n']);
    fprintf(dataFile,['* debug: ' num2str(debug) '\n']);
    fprintf(dataFile,'*********************************************\n\n');
end

% print header to command window
fprintf('\n*********************************************\n');
fprintf('* Sustained Attention and Recognition Memory Experiment - Memory Test v.1.0\n');
fprintf(['* Date/Time: ' datestr(now,0) '\n']);
fprintf(['* Seed: ' num2str(seed) '\n']);
fprintf(['* Subject Number: ' num2str(subjectNum) '\n']);
fprintf(['* Subject Name: ' subjectName '\n']);
fprintf(['* Run Number: ' num2str(runNum) '\n']);
fprintf(['* debug: ' num2str(debug) '\n']);
fprintf('*********************************************\n\n');


%%

memRunStart = GetSecs;


%%

for iTrial = 1:nTrials
    % make textures
    imageTex = Screen('MakeTexture',mainWindow,images{memData.attCategs(iTrial),memData.images(iTrial)});
    Screen('PreloadTextures',mainWindow,imageTex);
    
    % wait for trigger and show image
    FlushEvents('keyDown');
    Priority(MaxPriority(screenNum));
    Screen('FillRect',mainWindow,backColor);
    Screen('DrawTexture',mainWindow,imageTex,imageRect,centerRect);
    Screen('DrawTexture',mainWindow,conf_textures{1},[],distConfRect);
    Screen(mainWindow,'FillOval',fixColor,fixDotRect);
    
    if iTrial==1
        memData.actualTrialOnsets(iTrial) = Screen('Flip',mainWindow,memRunStart+IBI);
    else
        memData.actualTrialOnsets(iTrial) = Screen('Flip',mainWindow,memData.actualTrialOffsets(iTrial-1)+ITI);
    end
    
    while KbCheck; end  
    while 1
        % check for responses if none received yet
        if isnan(memData.rts(iTrial))
            [keyIsDown, secs, keyCode] = KbCheck(DEVICE); % -1 checks all keyboards
            if keyIsDown
                %if (keyCode(ONE)) || (keyCode(TWO)) || (keyCode(THREE)) || (keyCode(FOUR))
                memData.rts(iTrial) = secs-memData.actualTrialOnsets(iTrial);
                memData.resps(iTrial) = find(keyCode,1);
                switch memData.resps(iTrial)
                    case ONE
                        memData.rating(iTrial) = 1;
                    case TWO
                        memData.rating(iTrial) = 2;
                    case THREE
                        memData.rating(iTrial) = 3;
                    case FOUR
                        memData.rating(iTrial) = 4;
                end
                
                if ((memData.memCategs(iTrial)==nogoTargets) || (memData.memCategs(iTrial)==goTargets)) && (memData.rating(iTrial)==3 || memData.rating(iTrial)==4)
                    memData.accs(iTrial) = 1;
                elseif ((memData.memCategs(iTrial)== nogoLures) || (memData.memCategs(iTrial)==goLures)) && (memData.rating(iTrial)==1 || memData.rating(iTrial)==2)
                    memData.accs(iTrial) = 1;
                else
                    memData.accs(iTrial) = 0;
                end
                break;
            end
        end
    end
    
    while KbCheck; end
    
    Screen('FillRect',mainWindow,backColor);
    Screen('DrawTexture',mainWindow,imageTex,imageRect,centerRect);
    %Screen('DrawTexture',mainWindow,conf_textures{1},[],distConfRect);
    if ~isnan(memData.rating(iTrial))
        Screen('DrawTexture',mainWindow,conf_textures{memData.rating(iTrial)+1},[],distConfRect);
    else
        Screen('DrawTexture',mainWindow,conf_textures{1},[],distConfRect);
    end
    Screen(mainWindow,'FillOval',respColor,fixDotRect);
    Screen('Flip',mainWindow);
    WaitSecs(ITI); 
    
    Screen('FillRect',mainWindow,backColor);
    Screen(mainWindow,'FillOval',fixColor,fixDotRect);
    memData.actualTrialOffsets(iTrial) = Screen('Flip',mainWindow);
    
    % print trial results
    if subjectNum
        fprintf(dataFile,'%d\t%d\t%d\t%d\t%d\t%d\t%d\t%.3f\n',runNum,iTrial,memData.attCategs(iTrial),memData.memCategs(iTrial),memData.images(iTrial),memData.resps(iTrial),memData.accs(iTrial),memData.rts(iTrial));
    end
    fprintf('%d\t%d\t%d\t%d\t%d\t%d\t%d\t%.3f\n',runNum,iTrial,memData.attCategs(iTrial),memData.memCategs(iTrial),memData.images(iTrial),memData.resps(iTrial),memData.accs(iTrial),memData.rts(iTrial));
    
    
end


% show instructions
endtaskinstruct = 'Great Job! You are now done with the experiment.';
tempBounds = Screen('TextBounds',mainWindow,endtaskinstruct);
Screen('drawtext',mainWindow,endtaskinstruct,centerX-tempBounds(3)/2,centerY-tempBounds(4)/5+textSpacing,textColor);
clear tempBounds;
Screen('Flip',mainWindow);

WaitSecs(4);

%% save

if subjectNum
    save([dataHeader '/memdata_' num2str(runNum) '_' datestr(now,30)],'memData','memRunStart');
end

% clean up and go home
sca;
ListenChar(1);
fclose('all');
end

