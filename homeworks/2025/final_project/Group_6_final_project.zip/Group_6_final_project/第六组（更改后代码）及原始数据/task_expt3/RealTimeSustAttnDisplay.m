function [blockData] = RealTimeSustAttnDisplay(subjectNum,subjectName,runNum,debug)
% function [blockData] = SustAttnDisplay(subjectNum,subjectName,runNum,debug)
%
% Scene sustained attention experiment
%
%
% REQUIRED INPUTS:
% - subjectNum:  participant number [any integer]
% - subjectName: participant initials [any string]
% - runNum:      run number [any integer]
% - debug:       whether debugging [1 if debugging/0 if not]
%
% OUTPUTS
% - blockData:   structure of experiment design and behavioral responses
%
% Written by:  Megan deBettencourt
% Version: 1.0
% Last modified: March 2014

%% check inputs

%check that there is a sufficient number of inputs
if nargin < 4;error('4 inputs are required: subjectNum, subjectName, runNum, debug');end

%check that inputs are of the right format
if ~isnumeric(subjectNum);error('subjectNum must be a number');end
if ~ischar(subjectName);error('subjectName must be a string');end
if ~isnumeric(runNum);error('runNum must be a number');end
if ((debug~=1) && (debug~=0));error('debug must be either 1 (if debugging) or 0 (if not)');end


%% Boilerplate

%make subject data folder, if it does not exist already
dataHeader = ['rtdata/' num2str(subjectNum)];
if ~exist(dataHeader);mkdir(dataHeader);end %#ok<EXIST>

%MdB write a check that the subject does not already exist 

%random seed
seed = sum(100*clock);
%RandStream.setDefaultStream(RandStream('mt19937ar','seed',seed));
RandStream.setGlobalStream(RandStream('mt19937ar','seed',seed));

%Screen('Preference', 'SkipSyncTests', 1);

%check whether debugging
if (debug) 
    Screen('Preference', 'SkipSyncTests', 1);
else
    ListenChar(2);  %prevent command window output
    HideCursor;     %hide mouse cursor    
end
    
%initialize system time calls
GetSecs;

%% Experimental Parameters

% block parameters
instructOn = 0;     % secs
instructDur = 2;    % secs
trialsPerBlock=500;
percentLures = 10;
nRandDesignTrials = 50;
nRememLures = (trialsPerBlock-nRandDesignTrials*2)*percentLures/100*.5;
nForgotLures = (trialsPerBlock-nRandDesignTrials*2)*percentLures/100*.5;

% trial timing
stimDur = 1;        % secs
respWindow = .9;    % secs
IBI = 4;

% display parameters
textColor = 0;      % black text
textFont = 'Arial';
textSize = 14;
textSpacing = 25;   
fixColor = 0;       % black fixation dot before response
respColor = 255;    % white fixation dot after response
backColor = 127;    % gray background
imageSize = 256;    % assumed square 
fixationSize = 4;   % pixels
progWidth = 400;    % image loading progress bar width
progHeight = 20;    % image loading progress bar height
ScreenResX = 1600;  % TO BE CHANGED - check the resolution of the running room computers!!!
ScreenResY = 900;   % TO BE CHANGED - check the resolution of the running room computers!

nSubCategs=2;
OUTDOOR=1;
INDOOR=2;

%% Response Mapping and Counterbalancing

% skyra: use current design button box (keys 1,2,3,4)
LEFT = KbName('h');
RIGHT = KbName('j');
DEVICE = -1;

starttaskInstruct = 'Please hit spacebar to start task';


%% Initialize Screens

screenNumbers = Screen('Screens');

if debug
    %show on first screen
    screenNum = 0;
    
    %draw on only top left quarter of screen
    %[screenX screenY] = Screen('WindowSize',screenNum);
    screenX = 500;
    screenY = 500;
else
    %show on last screen (e.g. second monitor)
    screenNum = screenNumbers(end);
    
    %draw on full screen
    [screenX screenY] = Screen('WindowSize',screenNum);
    
    %to ensure that the images are standardized (they take up the same degrees of the visual field) for all subjects
    if (screenX ~= ScreenResX) || (screenY ~= ScreenResY)
        fprintf('The screen dimensions may be incorrect. For screenNum = %d,screenX = %d (not 1152) and screenY = %d (not 864)',screenNum, screenX, screenY);
    end
end

%create main window
mainWindow = Screen(screenNum,'OpenWindow',backColor,[0 0 screenX screenY]);

% details of main window
centerX = screenX/2; centerY = screenY/2;
Screen(mainWindow,'TextFont',textFont);
Screen(mainWindow,'TextSize',textSize);

% placeholder for images
imageRect = [0,0,imageSize,imageSize];

% position of images
centerRect = [centerX-imageSize/2,centerY-imageSize/2,centerX+imageSize/2,centerY+imageSize/2];

% position of fixation dot
fixDotRect = [centerX-fixationSize,centerY-fixationSize,centerX+fixationSize,centerY+fixationSize];

% image loading progress bar
progRect = [centerX-progWidth/2,centerY-progHeight/2,centerX+progWidth/2,centerY+progHeight/2];


%% Load Images

cd instructimages;
for categ=1:nSubCategs
    
    % move into the right folder
    if (categ == OUTDOOR)
        cd outdoor;
    elseif (categ == INDOOR)
        cd indoor;
    else
        error('Impossible category!');
    end
    
    % get filenames
    dirList{categ} = dir;  %#ok<AGROW>
    dirList{categ} = dirList{categ}(3:end); %#ok<AGROW> %skip . & ..
    if (~isempty(dirList{categ}))
        if (strcmp(dirList{categ}(1).name,'.DS_Store')==1)
            dirList{categ} = dirList{categ}(2:end);  %#ok<AGROW>
        end
        
        if (strcmp(dirList{categ}(end).name,'Thumbs.db')==1)
            dirList{categ} = dirList{categ}(1:(end-1));  %#ok<AGROW>
        end
        
        instructNumImages(categ) = length(dirList{categ}); %#ok<AGROW>
        
        if (instructNumImages(categ)>0)
            
            % get images
            for img=1:instructNumImages(categ)
                
                % update progress bar
                Screen('FrameRect',mainWindow,0,progRect,10);
                Screen('FillRect',mainWindow,0,progRect);
                Screen('FillRect',mainWindow,[255 0 0],progRect-[0 0 round((1-img/instructNumImages(categ))*progWidth) 0]);
                Screen('Flip',mainWindow);
                
                % read images
                instructImages{categ,img} = imread(dirList{categ}(img).name);  %#ok<AGROW>
            end
            
            % randomize order of images in each run
            instructImageShuffle{categ} = randperm(instructNumImages(categ)); %#ok<AGROW>
            cd ..;
        end
    else
        error('Need at least one image per directory!');
    end
end
cd ..;
Screen('Flip',mainWindow);


cd images;
for categ=1:nSubCategs
    
    % move into the right folder
    if (categ == OUTDOOR)
        cd sunoutdoor550;
    elseif (categ == INDOOR)
        cd sunindoor550;
    else
        error('Impossible category!');
    end
    
    % get filenames
    dirList{categ} = dir;  %#ok<AGROW>
    dirList{categ} = dirList{categ}(3:end); %#ok<AGROW> %skip . & ..
    if (~isempty(dirList{categ}))
        if (strcmp(dirList{categ}(1).name,'.DS_Store')==1)
            dirList{categ} = dirList{categ}(2:end);  %#ok<AGROW>
        end
        
        if (strcmp(dirList{categ}(end).name,'Thumbs.db')==1)
            dirList{categ} = dirList{categ}(1:(end-1));  %#ok<AGROW>
        end
        
        numImages(categ) = length(dirList{categ}); %#ok<AGROW>
        %numImages(categ) = 100; %FOR TESTING!!!!
        
        if (numImages(categ)>0)
            
            % get images
            for img=1:numImages(categ)
                
                % update progress bar
                Screen('FrameRect',mainWindow,0,progRect,10);
                Screen('FillRect',mainWindow,0,progRect);
                Screen('FillRect',mainWindow,[255 0 0],progRect-[0 0 round((1-img/numImages(categ))*progWidth) 0]);
                Screen('Flip',mainWindow);
                
                % read images
                imageNames{categ,img} = dirList{categ}(img).name;
                images{categ,img} = imread(dirList{categ}(img).name);  %#ok<AGROW>
            end
            
            % randomize order of images in each run
            imageShuffle{categ} = randperm(numImages(categ)); %#ok<AGROW>
            cd ..;
        end
    else
        error('Need at least one image per directory!');
    end
end
cd ..;
Screen('Flip',mainWindow);


%% Output Files Setup

if subjectNum
    % open and set-up output file
    dataFile = fopen([dataHeader '/behavior.txt'],'a');
    fprintf(dataFile,'\n*********************************************\n');
    fprintf(dataFile,'* Sustained Attention and Recognition Memory Experiment - Sustained Attention Task v.1.0\n');
    fprintf(dataFile,['* Date/Time: ' datestr(now,0) '\n']);
    fprintf(dataFile,['* Seed: ' num2str(seed) '\n']);
    fprintf(dataFile,['* Subject Number: ' num2str(subjectNum) '\n']);
    fprintf(dataFile,['* Subject Name: ' subjectName '\n']);
    fprintf(dataFile,['* Run Number: ' num2str(runNum) '\n']);
    fprintf(dataFile,['* debug: ' num2str(debug) '\n']);
    fprintf(dataFile,'*********************************************\n\n');
end

% print header to command window
fprintf('\n*********************************************\n');
fprintf('* Sustained Attention and Recognition Memory Experiment - Sustained Attention Task v.1.0\n');
fprintf(['* Date/Time: ' datestr(now,0) '\n']);
fprintf(['* Seed: ' num2str(seed) '\n']);
fprintf(['* Subject Number: ' num2str(subjectNum) '\n']);
fprintf(['* Subject Name: ' subjectName '\n']);
fprintf(['* Run Number: ' num2str(runNum) '\n']);
fprintf(['* debug: ' num2str(debug) '\n']);
fprintf('*********************************************\n\n');


%% set up

if (mod(subjectNum,2)==1)
    rareCateg = INDOOR;
    freqCateg = OUTDOOR;
    OUTDOORRESP = LEFT; 
    INDOORRESP = RIGHT;
else
    rareCateg = OUTDOOR;
    freqCateg = INDOOR;
    OUTDOORRESP = RIGHT;
    INDOORRESP = LEFT;
end
freqCategResp = LEFT;
rareCategResp = RIGHT;

blockData.trialsPerBlock = trialsPerBlock;
blockData.trial = 1:(blockData.trialsPerBlock);
blockData.plannedTrialOnsets = nan(1,blockData.trialsPerBlock);
blockData.actualTrialOnsets = nan(1,blockData.trialsPerBlock);
blockData.correctResponses = nan(1,blockData.trialsPerBlock);
blockData.rts = nan(1,blockData.trialsPerBlock);
blockData.rtsEst = nan(blockData.trialsPerBlock,blockData.trialsPerBlock);
blockData.rtsResid = nan(blockData.trialsPerBlock,blockData.trialsPerBlock);
blockData.responses = nan(1,blockData.trialsPerBlock);
blockData.accs = nan(1,blockData.trialsPerBlock);
nLuresFirstRand = 0;
nLuresLastRand = 0;
nDesiredLures = ceil(blockData.trialsPerBlock*percentLures/100);
nDesiredRandLures = ceil(nRandDesignTrials*percentLures/100);
blockData.categs = zeros(1,blockData.trialsPerBlock);
while (blockData.categs(1)==rareCateg) || nLuresFirstRand~=nDesiredRandLures || nLuresLastRand~=nDesiredRandLures %checks if the number of lure trials is not exactly 10%
    blockData.categs(1:nRandDesignTrials) = RandSample([freqCateg*ones(1,100-percentLures) rareCateg*ones(1,percentLures)],[1 nRandDesignTrials]);
    blockData.categs((nRandDesignTrials+1):(blockData.trialsPerBlock-nRandDesignTrials)) = freqCateg;
    blockData.categs((blockData.trialsPerBlock-nRandDesignTrials+1):blockData.trialsPerBlock) = RandSample([freqCateg*ones(1,100-percentLures) rareCateg*ones(1,percentLures)],[1 nRandDesignTrials]);
    nLuresFirstRand = sum(blockData.categs(1:nRandDesignTrials)==rareCateg);
    nLuresLastRand = sum(blockData.categs(1:nRandDesignTrials)==rareCateg);
end
blockData.resps = NaN(1,blockData.trialsPerBlock);
blockData.corrresps((blockData.categs==freqCateg)) = freqCategResp;
blockData.corrresps((blockData.categs==rareCateg)) = rareCategResp;
blockData.memPredict= zeros(1,blockData.trialsPerBlock);
blockData.forget = zeros(1,blockData.trialsPerBlock);
blockData.remember = zeros(1,blockData.trialsPerBlock);

categCounter = zeros(1,nSubCategs);
for iTrial = 1:blockData.trialsPerBlock;
    % update image counters
    categCounter(blockData.categs(iTrial)) = categCounter(blockData.categs(iTrial))+1;
    % reset counter and reshuffle images if list has been exhausted
    if (categCounter(blockData.categs(iTrial)) > numImages(blockData.categs(iTrial)))
        categCounter(blockData.categs(iTrial)) = 1; % start counter over, and reshuffle images
        imageShuffle{blockData.categs(iTrial)} = randperm(numImages(blockData.categs(iTrial))); %#ok<AGROW>
    end
    % get current images
    blockData.images(iTrial) = imageShuffle{blockData.categs(iTrial)}(categCounter(blockData.categs(iTrial))); 
end

%% Task Instructions

% clear screen
Screen(mainWindow,'FillRect',backColor);
Screen('Flip',mainWindow);
FlushEvents('keyDown');

% show instructions
welcomeInstruct = {'Welcome! In this task we are interested in how people categorize pictures of places';'You will be shown images on the screen. Your task will be to decide whether each place as indoor or outdoor by pressing a button';['If the place is outdoor respond with the ' KbName(OUTDOORRESP) ' key'];['If the place is indoor respond with the ' KbName(INDOORRESP) ' key'];' ';'Use your index and middle finger of your right hand';' ';'Hit spacebar to continue to some practice trials'};
for instruct=1:length(welcomeInstruct)
    tempBounds = Screen('TextBounds',mainWindow,welcomeInstruct{instruct});
    Screen('drawtext',mainWindow,welcomeInstruct{instruct},centerX-tempBounds(3)/2,centerY-tempBounds(4)/5+textSpacing*(instruct-1),textColor);
    clear tempBounds;
end
Screen('Flip',mainWindow);

% wait for experimenter to advance with space bar
FlushEvents('keyDown');
while KbCheck; end 
[~, ~, keyCode] = KbCheck(-1); % -1 checks all keyboards
while ~keyCode(KbName('space'))
    [~, ~, keyCode] = KbCheck(-1);
end
Screen(mainWindow,'FillRect',backColor);
Screen('Flip',mainWindow);

%% practice trials
doInstruct = 1;
if doInstruct
    iTrial = 1;
    imageTex = Screen('MakeTexture',mainWindow,instructImages{OUTDOOR,1});
    Screen('FillRect',mainWindow,backColor);
    Screen('DrawTexture',mainWindow,imageTex,imageRect,centerRect);
    Screen(mainWindow,'FillOval',fixColor,fixDotRect);
    trialOnsets(iTrial) = Screen('Flip',mainWindow);
    rts(iTrial) = NaN;
    resps(iTrial) = NaN;
    while KbCheck; end
    while(resps(iTrial)~=OUTDOORRESP)
        % check for responses if none received yet
        if isnan(rts(iTrial))
            [keyIsDown, secs, keyCode] = KbCheck(-1); % -1 checks all keyboards
            if keyIsDown
                if (keyCode(OUTDOORRESP)) %|| keyCode(RIGHT))
                    rts(iTrial) = secs-trialOnsets(iTrial);
                    resps(iTrial) = find(keyCode,1);
                    Screen('FillRect',mainWindow,backColor);
                    Screen('DrawTexture',mainWindow,imageTex,imageRect,centerRect);
                    Screen(mainWindow,'FillOval',respColor,fixDotRect);
                    Screen('Flip',mainWindow);
                end
            end
        end
    end
    
    % show instructions
    Screen('FillRect',mainWindow,backColor);
    Screen('DrawTexture',mainWindow,imageTex,imageRect,centerRect);
    Screen(mainWindow,'FillOval',respColor,fixDotRect);
    topInstruct = {'Great!'};
    tempBounds = Screen('TextBounds',mainWindow,topInstruct{1});
    Screen('drawtext',mainWindow,topInstruct{1},centerX-tempBounds(3)/2,centerY-tempBounds(4)/5+textSpacing*-7,textColor);
    clear tempBounds;
    bottomInstruct = {'Now let''s try another place image','Press spacebar to continue'};
    tempBounds = Screen('TextBounds',mainWindow,bottomInstruct{1});
    Screen('drawtext',mainWindow,bottomInstruct{1},centerX-tempBounds(3)/2,centerY-tempBounds(4)/5+textSpacing*7,textColor);
    clear tempBounds;
    tempBounds = Screen('TextBounds',mainWindow,bottomInstruct{2});
    Screen('drawtext',mainWindow,bottomInstruct{2},centerX-tempBounds(3)/2,centerY-tempBounds(4)/5+textSpacing*8,textColor);
    clear tempBounds;
    Screen('Flip',mainWindow);
    
    % wait for experimenter to advance with space bar
    FlushEvents('keyDown');
    while KbCheck; end
    [~, ~, keyCode] = KbCheck(-1); % -1 checks all keyboards
    while ~keyCode(KbName('space'))
        [~, ~, keyCode] = KbCheck(-1);
    end
    Screen(mainWindow,'FillRect',backColor);
    Screen('Flip',mainWindow);
    
    iTrial = 1;
    imageTex = Screen('MakeTexture',mainWindow,instructImages{INDOOR,1});
    Screen('FillRect',mainWindow,backColor);
    Screen('DrawTexture',mainWindow,imageTex,imageRect,centerRect);
    Screen(mainWindow,'FillOval',fixColor,fixDotRect);
    trialOnsets(iTrial) = Screen('Flip',mainWindow);
    rts(iTrial) = NaN;
    resps(iTrial) = NaN;
    while KbCheck; end
    while(resps(iTrial)~=INDOORRESP)
        % check for responses if none received yet
        if isnan(rts(iTrial))
            [keyIsDown, secs, keyCode] = KbCheck(-1); % -1 checks all keyboards
            if keyIsDown
                if (keyCode(INDOORRESP)) %keyCode(LEFT) ||
                    rts(iTrial) = secs-trialOnsets(iTrial);
                    resps(iTrial) = find(keyCode,1);
                    Screen('FillRect',mainWindow,backColor);
                    Screen('DrawTexture',mainWindow,imageTex,imageRect,centerRect);
                    Screen(mainWindow,'FillOval',respColor,fixDotRect);
                    Screen('Flip',mainWindow);
                end
            end
        end
    end
    
    % show instructions
    Screen('FillRect',mainWindow,backColor);
    Screen('DrawTexture',mainWindow,imageTex,imageRect,centerRect);
    Screen(mainWindow,'FillOval',respColor,fixDotRect);
    topInstruct = {'Great!'};
    tempBounds = Screen('TextBounds',mainWindow,topInstruct{1});
    Screen('drawtext',mainWindow,topInstruct{1},centerX-tempBounds(3)/2,centerY-tempBounds(4)/5+textSpacing*-7,textColor);
    clear tempBounds;
    bottomInstruct = {'Now let''s try a few images in a row. The images will be presented rapidly so get ready!','Press spacebar to continue'};
    tempBounds = Screen('TextBounds',mainWindow,bottomInstruct{1});
    Screen('drawtext',mainWindow,bottomInstruct{1},centerX-tempBounds(3)/2,centerY-tempBounds(4)/5+textSpacing*7,textColor);
    clear tempBounds;
    tempBounds = Screen('TextBounds',mainWindow,bottomInstruct{2});
    Screen('drawtext',mainWindow,bottomInstruct{2},centerX-tempBounds(3)/2,centerY-tempBounds(4)/5+textSpacing*8,textColor);
    clear tempBounds;
    Screen('Flip',mainWindow);
    
    % wait for experimenter to advance with space bar
    FlushEvents('keyDown');
    while KbCheck; end
    [~, ~, keyCode] = KbCheck(-1); % -1 checks all keyboards
    while ~keyCode(KbName('space'))
        [~, ~, keyCode] = KbCheck(-1);
    end
    Screen(mainWindow,'FillRect',backColor);
    Screen('Flip',mainWindow);
    
    nInstructTrials = 10;
    accs = nan(1,nInstructTrials);
    instructBlockRep = 0;
    while nanmean(accs)<.9 || isnan(nanmean(accs))
        
        instructBlockRep = 1;%instructBlockRep+1;
        categorder = [ones(1,5) 2*ones(1,5)];
        categorder = categorder(randperm(nInstructTrials));
        corrresps((categorder==freqCateg)) = freqCategResp;
        corrresps((categorder==rareCateg)) = rareCategResp;
        for iTrial = 1:10
            imageTex = Screen('MakeTexture',mainWindow,instructImages{categorder(iTrial),((instructBlockRep-1)*10)+1+iTrial});
            Screen('FillRect',mainWindow,backColor);
            Screen('DrawTexture',mainWindow,imageTex,imageRect,centerRect);
            Screen(mainWindow,'FillOval',fixColor,fixDotRect);
            instructTrialOnsets(iTrial) = Screen('Flip',mainWindow);
            instructTrialTimeout(iTrial) = instructTrialOnsets(iTrial)+respWindow;
            rts(iTrial) = NaN;
            resps(iTrial) = NaN;
            
            while (GetSecs < instructTrialTimeout(iTrial)) && KbCheck; end
            while (GetSecs < instructTrialTimeout(iTrial))
                % check for responses if none received yet
                if isnan(rts(iTrial))
                    [keyIsDown, secs, keyCode] = KbCheck(-1); % -1 checks all keyboards
                    if keyIsDown
                        if (keyCode(LEFT) || keyCode(RIGHT))
                            rts(iTrial) = secs-instructTrialOnsets(iTrial);
                            resps(iTrial) = find(keyCode,1);
                            Screen('FillRect',mainWindow,backColor);
                            %if (stimOn) % leave image up if response before image duration
                            Screen('DrawTexture',mainWindow,imageTex,imageRect,centerRect);
                            %end
                            Screen(mainWindow,'FillOval',respColor,fixDotRect);
                            Screen('Flip',mainWindow);
                        end
                    end
                end
            end
            
            %accuracy
            if (resps(iTrial)==corrresps(iTrial)) %made correct response
                accs(iTrial) = 1;
            else
                accs(iTrial) = 0;
            end
            
        end
        
        Screen('FillRect',mainWindow,backColor);
        
        %block summary
        if isnan(nanmean(accs))
            summaryText = {'We didn''t get any responses from you, so let''s try it again.',...
                ['This time, be sure to hit the ' KbName(OUTDOORRESP) ' key for outdoor scenes and the ' KbName(INDOORRESP) ' key for indoor scenes'],...
                ' ','Press spacebar to continue'};
        elseif nanmean(accs)>=.9
            summaryText = {sprintf('Great job! Your accuracy was %d%%',nanmean(accs)*100),...
                ' ','Press spacebar to continue'};
        elseif nanmean(accs)<.9
            summaryText = {sprintf('Your accuracy was only %d%%',nanmean(accs)*100),...
                'In order to continue to the main part of the experiment, you need to get 90% or better',...
                ' ','Let''s try a bit more practice before we start the task',...
                ['Remember to hit the ' KbName(OUTDOORRESP) ' key for outdoor scenes and the ' KbName(INDOORRESP) ' key for indoor scenes'],...
                'And try to respond quickly and accurately before the next image appears',...
                ' ','Press spacebar to continue'};
        end
        for instruct=1:length(summaryText)
            tempBounds = Screen('TextBounds',mainWindow,summaryText{instruct});
            Screen('drawtext',mainWindow,summaryText{instruct},centerX-tempBounds(3)/2,centerY-tempBounds(4)/5+textSpacing*(instruct-1),textColor);
            clear tempBounds;
        end
        Screen('Flip',mainWindow);
        
        %wait for experimenter to advance with space bar
        FlushEvents('keyDown');
        while KbCheck; end
        [~, ~, keyCode] = KbCheck(-1); % -1 checks all keyboards
        while ~keyCode(KbName('space'))
            [~, ~, keyCode] = KbCheck(-1);
        end
        Screen(mainWindow,'FillRect',backColor);
        Screen('Flip',mainWindow);
    end
    
end

%% Experiment Instructions

% clear screen
Screen(mainWindow,'FillRect',backColor);
Screen('Flip',mainWindow);
FlushEvents('keyDown');

% show instructions
tempBounds = Screen('TextBounds',mainWindow,starttaskInstruct);
Screen('drawtext',mainWindow,starttaskInstruct,centerX-tempBounds(3)/2,centerY-tempBounds(4)/5+textSpacing,textColor);
clear tempBounds;
Screen('Flip',mainWindow);

% wait for experimenter to advance with space bar
FlushEvents('keyDown');
while KbCheck; end 
[~, ~, keyCode] = KbCheck(-1); % -1 checks all keyboards
while ~keyCode(KbName('space'))
    [~, ~, keyCode] = KbCheck(-1);
end
Screen(mainWindow,'FillRect',backColor);
Screen('Flip',mainWindow);


%% Start Experiment

Priority(MaxPriority(screenNum));
Screen(mainWindow,'FillRect',backColor);
Screen(mainWindow,'FillOval',fixColor,fixDotRect);
runStart = GetSecs;
Screen('Flip',mainWindow);
Priority(0);

% prepare for trial sequence
if subjectNum
    fprintf(dataFile,'run\ttrl\ttdf\tsct\tsimg\tcrsp\trsp\tacc\trt\n');
end
fprintf('run\ttrl\ttdf\tsct\tsimg\tcrsp\trsp\tacc\trt\n');
    
% timing
blockData.plannedTrialOnsets = runStart + 2 + (stimDur:stimDur:(stimDur*blockData.trialsPerBlock));


%% start trial sequence

for iTrial=1:(blockData.trialsPerBlock)
    
    %real-time design
    if (iTrial>nRandDesignTrials) && (iTrial<(blockData.trialsPerBlock-nRandDesignTrials+1))
        %linearly regress rt
        indFit = find(~isnan(blockData.rts(1:(iTrial-1))));
        blockData.linfit(:,iTrial) = polyfit(indFit,blockData.rts(indFit),1);
        blockData.rtsEst(iTrial,1:(iTrial-1)) = blockData.linfit(1,iTrial).*blockData.trial(1:(iTrial-1))+blockData.linfit(2,iTrial);
        blockData.rtsResid(iTrial,1:(iTrial-1)) = blockData.rts(1:(iTrial-1))-blockData.rtsEst(iTrial,1:(iTrial-1));
        blockData.meanRTresid(iTrial) = nanmean(blockData.rtsResid(iTrial,1:(iTrial-1)));
        blockData.stdRTresid(iTrial) = nanstd(blockData.rtsResid(iTrial,1:(iTrial-1)));
        if ~any(blockData.categs((iTrial-3):(iTrial-1))==rareCateg) && ~all(isnan(blockData.rts((iTrial-3):(iTrial-1)))) %check for most recent rareTrial
            if (sum(blockData.forget(1:iTrial))<nForgotLures) && nanmean(blockData.rtsResid(iTrial,(iTrial-3):(iTrial-1)))<(blockData.meanRTresid(iTrial)-blockData.stdRTresid(iTrial))
                %forgettrial
                blockData.categs(iTrial) = rareCateg;
                blockData.memPredict(iTrial) = 1;
                blockData.forget(iTrial) = 1;
                blockData.remember(iTrial) = 0;
                blockData.corrresps(iTrial) = rareCategResp;
                categCounter(blockData.categs(iTrial)) = categCounter(blockData.categs(iTrial))+1;
                blockData.images(iTrial) = imageShuffle{blockData.categs(iTrial)}(categCounter(blockData.categs(iTrial)));
            elseif sum(blockData.remember(1:iTrial))<nRememLures && nanmean(blockData.rtsResid(iTrial,(iTrial-3):(iTrial-1)))>(blockData.meanRTresid(iTrial)+blockData.stdRTresid(iTrial))
                %remember trial
                blockData.categs(iTrial) = rareCateg;
                blockData.memPredict(iTrial) = 1;
                blockData.forget(iTrial) = 0;
                blockData.remember(iTrial) = 1;
                blockData.corrresps(iTrial) = rareCategResp;
                categCounter(blockData.categs(iTrial)) = categCounter(blockData.categs(iTrial))+1;
                blockData.images(iTrial) = imageShuffle{blockData.categs(iTrial)}(categCounter(blockData.categs(iTrial)));
            end 
        end
    end
    
    % make textures
    blockData.imageName{iTrial} = imageNames{blockData.categs(iTrial),blockData.images(iTrial)};
    imageTex = Screen('MakeTexture',mainWindow,images{blockData.categs(iTrial),blockData.images(iTrial)});
    Screen('PreloadTextures',mainWindow,imageTex);
    
    % wait for trigger and show image
    FlushEvents('keyDown');
    Priority(MaxPriority(screenNum));
    Screen('FillRect',mainWindow,backColor);
    Screen('DrawTexture',mainWindow,imageTex,imageRect,centerRect);
    Screen(mainWindow,'FillOval',fixColor,fixDotRect);
    tRespTimeout = blockData.plannedTrialOnsets(iTrial)+respWindow; %response timeout
    
    blockData.actualTrialOnsets(iTrial) = Screen('Flip',mainWindow,blockData.plannedTrialOnsets(iTrial));
    while (GetSecs < tRespTimeout) && KbCheck; end  
    while(GetSecs < tRespTimeout)
        
        % check for responses if none received yet
        if isnan(blockData.rts(iTrial))
            [keyIsDown, secs, keyCode] = KbCheck(-1); % -1 checks all keyboards
            if keyIsDown
                if (keyCode(LEFT) || keyCode(RIGHT))
                    blockData.rts(iTrial) = secs-blockData.actualTrialOnsets(iTrial); 
                    blockData.resps(iTrial) = find(keyCode,1); 
                    Screen('FillRect',mainWindow,backColor);
                    %if (stimOn) % leave image up if response before image duration
                    Screen('DrawTexture',mainWindow,imageTex,imageRect,centerRect);
                    %end
                    Screen(mainWindow,'FillOval',respColor,fixDotRect);
                    Screen('Flip',mainWindow);
                end
            end
        end
    end
    
    %accuracy
    if (blockData.resps(iTrial)==blockData.corrresps(iTrial)) %made correct response
        blockData.accs(iTrial) = 1;
    else
        blockData.accs(iTrial) = 0;
    end
    
    
    % print trial results
    if subjectNum
        fprintf(dataFile,'%d\t%d\t%.3f\t%d\t%d\t%d\t%d\t%d\t%.3f\n',runNum,iTrial,blockData.actualTrialOnsets(iTrial)-blockData.plannedTrialOnsets(iTrial),blockData.categs(iTrial),blockData.images(iTrial),blockData.corrresps(iTrial),blockData.resps(iTrial),blockData.accs(iTrial),blockData.rts(iTrial));
    end
    fprintf('%d\t%d\t%.3f\t%d\t%d\t%d\t%d\t%d\t%.3f\n',runNum,iTrial,blockData.actualTrialOnsets(iTrial)-blockData.plannedTrialOnsets(iTrial),blockData.categs(iTrial),blockData.images(iTrial),blockData.corrresps(iTrial),blockData.resps(iTrial),blockData.accs(iTrial),blockData.rts(iTrial));
    
end % trial loop

Screen('FillRect',mainWindow,backColor);
Screen(mainWindow,'FillOval',fixColor,fixDotRect);
endOfBlock=Screen('Flip',mainWindow);

endText={'Great job! You are now done with part 1 of the experiment',' ','Please hit spacebar to continue'};
for instruct=1:length(endText)
    tempBounds = Screen('TextBounds',mainWindow,endText{instruct});
    Screen('drawtext',mainWindow,endText{instruct},centerX-tempBounds(3)/2,centerY-tempBounds(4)/5+textSpacing*(instruct-1),textColor);
    clear tempBounds;
end
Screen('Flip',mainWindow);


Screen('FillRect',mainWindow,backColor);
Screen(mainWindow,'FillOval',fixColor,fixDotRect);
Screen('Flip',mainWindow,endOfBlock+IBI);
pause(IBI);

%% save

if subjectNum
    save([dataHeader '/blockdata_' num2str(runNum) '_' datestr(now,30)],'blockData','runStart');
end

% clean up and go home
sca;
ListenChar(1);
fclose('all');
end
