# Experiment 3

These scripts are provided by Megan deBettencourt who collected the data for Experiment 3 (published in deBettencourt et al., 2018, PB&R)

Note that they are not intended to be executed from this directory directly. Rather, they are included for distribution of this project to comprehensively illustrate any of the data fields. 
