library(tidyverse)
library(lme4)
library(optimx)
library(BayesFactor)
library(effsize)
library(mousetrap)
library(DescTools)
#library(BayesianFirstAid)

rm(list=ls())

setwd("/wakelandhart_attmembility")


######################## Load & filter data ######################## 
#read in memorablity data
mem <- read.csv("./data_expt1/memscores-30-Jun-2021.csv")%>%
  rename(imagename=filename)%>%
  mutate(cr=hr-far)

# read in attention data and make distinct subject numbers
att_exp2 <- read.csv("./data_expt2/Expt2_attnmem.csv")%>%
  mutate(exp="exp2")
att_exp2$subject_num = att_exp2$subject_num+100

att_exp3 <- read.csv("./data_expt3/Expt3_attnmem.csv")%>%
  mutate(exp="exp3")
att_exp3$subject_num = att_exp3$subject_num+200

#join attention data, keep only infrequent category trials, exclude subjects for poor attention task performance
all_att <- rbind(att_exp3,att_exp2)%>%
  filter( subject_num!=125 & subject_num!=226)%>%
  rename(imagename=image_name)

is.nan.data.frame <- function(x)
  do.call(cbind, lapply(x, is.nan))

all_att[is.nan(all_att)] <- NA

# add image category to memorability data
mem2 <- merge(mem, all_att[, c("image_categname", "imagename")], by ="imagename", all = TRUE)
mem2 <- mem2[!duplicated(mem2$imagename),]

# filter to keep only infrequent trials
all_att <- all_att %>% filter((subject_infreq_categ == "indoor" & image_categname == "indoor")|(subject_infreq_categ == "outdoor" & image_categname == "outdoor"))

#merge memorability and attention data
all_att_memorab <- merge(all_att,mem, by ="imagename")
all_att_memorab$subject_num <- factor(all_att_memorab$subject_num)
all_att_memorab <- all_att_memorab %>%
  mutate(mem_remembered_thr4= ifelse(all_att_memorab$mem_rating == 4, 1, 0))


######################## Pretrial RT predicts attention ######################## 
mean_pretrial_rts <- all_att_memorab %>% 
  group_by(exp,subject_num,attn_acc) %>% 
  summarise(attn_pretrial_rtsresid = mean(attn_pretrial_rtsresid, na.rm = TRUE))

# Sort by exp, then attn_acc, then subject_num
mean_pretrial_rts          <- mean_pretrial_rts[order(mean_pretrial_rts$exp, mean_pretrial_rts$attn_acc, mean_pretrial_rts$subject_num), ]
mean_pretrial_rts$attn_acc <- as.factor(mean_pretrial_rts$attn_acc)

# compare compare pre-correct vs. pre-lapse detrended RTs within subjects
mean_pre_correct_exp2 <- mean(mean_pretrial_rts[mean_pretrial_rts$exp=='exp2' & mean_pretrial_rts$attn_acc=='1',]$attn_pretrial_rtsresid)
mean_pre_lapse_exp2   <- mean(mean_pretrial_rts[mean_pretrial_rts$exp=='exp2' & mean_pretrial_rts$attn_acc=='0',]$attn_pretrial_rtsresid)
mean_pre_correct_exp3 <- mean(mean_pretrial_rts[mean_pretrial_rts$exp=='exp3' & mean_pretrial_rts$attn_acc=='1',]$attn_pretrial_rtsresid)
mean_pre_lapse_exp3   <- mean(mean_pretrial_rts[mean_pretrial_rts$exp=='exp3' & mean_pretrial_rts$attn_acc=='0',]$attn_pretrial_rtsresid)

data_exp2 <- mean_pretrial_rts[mean_pretrial_rts$exp == 'exp2', ]
group0_exp2 <- data_exp2$attn_pretrial_rtsresid[data_exp2$attn_acc == 0]
group1_exp2 <- data_exp2$attn_pretrial_rtsresid[data_exp2$attn_acc == 1]
t.test(group0_exp2, group1_exp2,
       alternative = "two.sided",
       paired = TRUE,
       var.equal = TRUE,
       conf.level = 0.95)
data_exp3 <- mean_pretrial_rts[mean_pretrial_rts$exp == 'exp3', ]
group0_exp3 <- data_exp3$attn_pretrial_rtsresid[data_exp3$attn_acc == 0]
group1_exp3 <- data_exp3$attn_pretrial_rtsresid[data_exp3$attn_acc == 1]
t.test(group0_exp3, group1_exp3,
       alternative = "two.sided",
       paired = TRUE,
       var.equal = TRUE,
       conf.level = 0.95)

cohen.d(attn_pretrial_rtsresid ~ attn_acc | Subject(subject_num), data = mean_pretrial_rts[mean_pretrial_rts$exp=='exp2',], paired=TRUE)
cohen.d(attn_pretrial_rtsresid ~ attn_acc | Subject(subject_num), data = mean_pretrial_rts[mean_pretrial_rts$exp=='exp3',], paired=TRUE)

######################## Mixed effects models ######################## 
attmem_drop_na<-all_att_memorab%>%
  dplyr::select(mem_remembered_thr4, cr,attn_pretrial_rtsresid, subject_num, exp, image_num,attn_trialnum)%>%
  drop_na()
attmem_drop_na$subject_num <- factor(attmem_drop_na$subject_num)
attmem_drop_na <- scale_within(attmem_drop_na, variables=c("attn_pretrial_rtsresid", "cr"), within="subject_num",prefix="scale_")
attmem_drop_na_exp2 <- attmem_drop_na %>%
  filter(exp=="exp2")
attmem_drop_na_exp3 <- attmem_drop_na %>%
  filter(exp=="exp3")

### Separate models
#Both exps: cr
regression_cr_both   <- glmer(mem_remembered_thr4 ~ scale_cr + (1 | exp/subject_num), data=attmem_drop_na, family = binomial(link = "logit"), control = glmerControl(optimizer ='optimx', optCtrl=list(method='L-BFGS-B')))

#Both exps: attn
regression_attn_both <- glmer(mem_remembered_thr4 ~ scale_attn_pretrial_rtsresid + (1 | exp/subject_num), data=attmem_drop_na, family = binomial(link = "logit"), control = glmerControl(optimizer ='optimx', optCtrl=list(method='L-BFGS-B')))

#Just cr by experiment
regression_cr1 <- glmer(mem_remembered_thr4 ~ scale_cr + (1 | subject_num), data=attmem_drop_na[attmem_drop_na$exp=="exp2",],family = binomial(link = "logit"), control = glmerControl(optimizer ='optimx', optCtrl=list(method='L-BFGS-B')))
regression_cr2 <- glmer(mem_remembered_thr4 ~ scale_cr + (1 | subject_num), data=attmem_drop_na[attmem_drop_na$exp=="exp3",],family = binomial(link = "logit"), control = glmerControl(optimizer ='optimx', optCtrl=list(method='L-BFGS-B')))

#Just attn by experiment
regression_attn1 <- glmer(mem_remembered_thr4 ~ scale_attn_pretrial_rtsresid + (1 | subject_num), data=attmem_drop_na[attmem_drop_na$exp=="exp2",],family = binomial(link = "logit"), control = glmerControl(optimizer ='optimx', optCtrl=list(method='L-BFGS-B')))
regression_attn2 <- glmer(mem_remembered_thr4 ~ scale_attn_pretrial_rtsresid + (1 | subject_num), data=attmem_drop_na[attmem_drop_na$exp=="exp3",],family = binomial(link = "logit"), control = glmerControl(optimizer ='optimx', optCtrl=list(method='L-BFGS-B')))

summary(regression_cr_both)
summary(regression_attn_both)
summary(regression_cr1)
summary(regression_cr2)
summary(regression_attn1)
summary(regression_attn2)

### Joint models
#Joint model
regression_joint_full     <- glmer(mem_remembered_thr4 ~ scale_attn_pretrial_rtsresid+scale_cr + (1 | exp/subject_num), data=attmem_drop_na,family = binomial(link = "logit"), control = glmerControl(optimizer ='optimx', optCtrl=list(method='L-BFGS-B')))
regression_joint_full_int <- glmer(mem_remembered_thr4 ~ scale_attn_pretrial_rtsresid*scale_cr + (1 | exp/subject_num), data=attmem_drop_na,family = binomial(link = "logit"), control = glmerControl(optimizer ='optimx', optCtrl=list(method='L-BFGS-B')))

#Joint model by exp
regression_joint_exp1     <- glmer(mem_remembered_thr4 ~ scale_attn_pretrial_rtsresid+scale_cr + (1 | subject_num), data=attmem_drop_na[attmem_drop_na$exp=="exp2",], family = binomial(link = "logit"), control = glmerControl(optimizer ='optimx', optCtrl=list(method='L-BFGS-B')))
regression_joint_exp1_int <- glmer(mem_remembered_thr4 ~ scale_attn_pretrial_rtsresid*scale_cr + (1 | subject_num), data=attmem_drop_na[attmem_drop_na$exp=="exp2",], family = binomial(link = "logit"), control = glmerControl(optimizer ='optimx', optCtrl=list(method='L-BFGS-B')))

regression_joint_exp2     <- glmer(mem_remembered_thr4 ~ scale_attn_pretrial_rtsresid+scale_cr + (1 | subject_num), data=attmem_drop_na[attmem_drop_na$exp=="exp3",], family = binomial(link = "logit"), control = glmerControl(optimizer ='optimx', optCtrl=list(method='L-BFGS-B')))
regression_joint_exp2_int <- glmer(mem_remembered_thr4 ~ scale_attn_pretrial_rtsresid*scale_cr + (1 | subject_num), data=attmem_drop_na[attmem_drop_na$exp=="exp3",], family = binomial(link = "logit"), control = glmerControl(optimizer ='optimx', optCtrl=list(method='L-BFGS-B')))

summary(regression_joint_full)
summary(regression_joint_exp1)
summary(regression_joint_exp2)

summary(regression_joint_full_int)
summary(regression_joint_exp1_int)
summary(regression_joint_exp2_int)

### RMSE
library(sjstats)
performance::rmse(regression_cr_both)
performance::rmse(regression_attn_both)
performance::rmse(regression_joint_full)
performance::rmse(regression_joint_full_int)

### Anova: single-factor model/joint model comparisons using a likelihood ratio test
anova(regression_cr_both,regression_joint_full, test ="LRT")
anova(regression_attn_both,regression_joint_full, test ="LRT")

### Replicating models without within-subject z-scoring
regression_joint_full_noz <- glmer(mem_remembered_thr4 ~ attn_pretrial_rtsresid+cr + (1 | exp/subject_num), data=attmem_drop_na,family = binomial(link = "logit"), control = glmerControl(optimizer ='optimx', optCtrl=list(method='L-BFGS-B')))
summary(regression_joint_full_noz)


######################## Within-subject correlation between memorability and RT ######################## 

trial_bytrl2<- read.csv("./data_Expt2/expt2_imageattnrts.csv")%>%
  dplyr::filter(subject_num != 25)%>%
  dplyr::rename(imagename= image_name_freq)
trial_bytrl3<- read.csv("./data_Expt3/expt3_imageattnrts.csv")%>%
  dplyr::filter(subject_num != 26)%>%
  dplyr::rename(imagename= image_name_freq)
trial_bytrl2$subject_num = trial_bytrl2$subject_num+100
trial_bytrl3$subject_num = trial_bytrl3$subject_num+200
trial_bytrl <- rbind(trial_bytrl2,trial_bytrl3)%>%
  dplyr::filter( acc_freq == 1)

# add memorability data
trial_bytrl <- merge(trial_bytrl, mem, by ="imagename", all = TRUE)

# create new data frame and add RT-vs-memorability spearman rho for each subject
trial_bytrl            <- trial_bytrl[order(trial_bytrl$subject_num, trial_bytrl$imagename), ]
rt_by_mem              <- by(trial_bytrl, trial_bytrl$subject_num, function(x) {cor(x$rts_freq, x$cr, method="spearman")})
rt_by_mem.df           <- cbind(as.data.frame(unique(trial_bytrl$subject_num)),as.data.frame(as.matrix(rt_by_mem)))
colnames(rt_by_mem.df) <- c("subject_num","rho")

# get mean, max, min for each experiment
# Exp 2 
min(rt_by_mem.df[rt_by_mem.df$subject_num<200,]$rho)
max(rt_by_mem.df[rt_by_mem.df$subject_num<200,]$rho)
FisherZInv(mean(FisherZ(rt_by_mem.df[rt_by_mem.df$subject_num<200,]$rho)))

# Exp 3
min(rt_by_mem.df[rt_by_mem.df$subject_num>=200,]$rho)
max(rt_by_mem.df[rt_by_mem.df$subject_num>=200,]$rho)
FisherZInv(mean(FisherZ(rt_by_mem.df[rt_by_mem.df$subject_num>=200,]$rho)))

# group-level significance testing
attn_mem_within_rho_exp2 <- t.test(FisherZ(rt_by_mem.df[rt_by_mem.df$subject_num<200,]$rho),
                                       mu = 0, alternative = "two.sided", conf.level = 0.95)
attn_mem_within_rho_exp2$parameter
attn_mem_within_rho_exp2$statistic
attn_mem_within_rho_exp2$p.value
FisherZInv(attn_mem_within_rho_exp2$estimate)
FisherZInv(attn_mem_within_rho_exp2$conf.int)

attn_mem_within_rho_exp3   <- t.test(FisherZ(rt_by_mem.df[rt_by_mem.df$subject_num>=200,]$rho),
                                     mu = 0, alternative = "two.sided", conf.level = 0.95)
attn_mem_within_rho_exp3$parameter
attn_mem_within_rho_exp3$statistic
attn_mem_within_rho_exp3$p.value
FisherZInv(attn_mem_within_rho_exp3$estimate)
FisherZInv(attn_mem_within_rho_exp3$conf.int)

# group-level effect size and Bayes factor estimates
cohen.d(FisherZ(rt_by_mem.df[rt_by_mem.df$subject_num<200,]$rho)~ .)
cohen.d(FisherZ(rt_by_mem.df[rt_by_mem.df$subject_num>=200,]$rho)~ .)

ttestBF(FisherZ(rt_by_mem.df[rt_by_mem.df$subject_num<200,]$rho),
        alternative = "two.sided", conf.level = 0.95)
ttestBF(FisherZ(rt_by_mem.df[rt_by_mem.df$subject_num>=200,]$rho),
        alternative = "two.sided", conf.level = 0.95)

### Replication using all trials (not correct trials only)
trial_bytrl_all <- rbind(trial_bytrl2,trial_bytrl3)

# add memorability data
trial_bytrl_all <- merge(trial_bytrl_all, mem, by ="imagename", all = TRUE)%>%
  drop_na()

# create new data frame and add RT-vs-memorability spearman rho for each subject
trial_bytrl_all        <- trial_bytrl_all[order(trial_bytrl_all$subject_num, trial_bytrl_all$imagename), ]
rt_by_mem_all          <- by(trial_bytrl_all, trial_bytrl_all$subject_num, function(x) {cor(x$rts_freq, x$cr, method="spearman")})
rt_by_mem_all.df       <- cbind(as.data.frame(unique(trial_bytrl_all$subject_num)),as.data.frame(as.matrix(rt_by_mem_all)))
colnames(rt_by_mem_all.df) <- c("subject_num","rho")

# get mean, max, min for each experiment
# Exp 2 
min(rt_by_mem_all.df[rt_by_mem_all.df$subject_num<200,]$rho)
max(rt_by_mem_all.df[rt_by_mem_all.df$subject_num<200,]$rho)
FisherZInv(mean(FisherZ(rt_by_mem_all.df[rt_by_mem_all.df$subject_num<200,]$rho)))

# Exp 3
min(rt_by_mem_all.df[rt_by_mem_all.df$subject_num>=200,]$rho)
max(rt_by_mem_all.df[rt_by_mem_all.df$subject_num>=200,]$rho)
FisherZInv(mean(FisherZ(rt_by_mem_all.df[rt_by_mem_all.df$subject_num>=200,]$rho)))

# group-level significance testing
attn_mem_within_rho_exp2_all <- t.test(FisherZ(rt_by_mem_all.df[rt_by_mem_all.df$subject_num<200,]$rho),
                                   mu = 0, alternative = "two.sided", conf.level = 0.95)
attn_mem_within_rho_exp2_all$parameter
attn_mem_within_rho_exp2_all$statistic
attn_mem_within_rho_exp2_all$p.value
FisherZInv(attn_mem_within_rho_exp2_all$estimate)
FisherZInv(attn_mem_within_rho_exp2_all$conf.int)

attn_mem_within_rho_exp3_all   <- t.test(FisherZ(rt_by_mem_all.df[rt_by_mem_all.df$subject_num>=200,]$rho),
                                     mu = 0, alternative = "two.sided", conf.level = 0.95)
attn_mem_within_rho_exp3_all$parameter
attn_mem_within_rho_exp3_all$statistic
attn_mem_within_rho_exp3_all$p.value
FisherZInv(attn_mem_within_rho_exp3_all$estimate)
FisherZInv(attn_mem_within_rho_exp3_all$conf.int)

# group-level effect size and Bayes factor estimates
cohen.d(FisherZ(rt_by_mem_all.df[rt_by_mem_all.df$subject_num<200,]$rho)~ .)
cohen.d(FisherZ(rt_by_mem_all.df[rt_by_mem_all.df$subject_num>=200,]$rho)~ .)

ttestBF(FisherZ(rt_by_mem_all.df[rt_by_mem_all.df$subject_num<200,]$rho),
        alternative = "two.sided", conf.level = 0.95)
ttestBF(FisherZ(rt_by_mem_all.df[rt_by_mem_all.df$subject_num>=200,]$rho),
        alternative = "two.sided", conf.level = 0.95)

######################## Within-subject logistic regression models ######################## 
#Within subject joint model- both exps
within_sub_joint_model_coefs <- data.frame(exp = numeric(0), subject_num=numeric(0), intercept=numeric(0), cr_coef=numeric(0), attn_pretrial_rtsresid_coef=numeric(0))
for (i in unique(attmem_drop_na$subject_num)){
  within_sub_model <- glm(mem_remembered_thr4 ~ scale_cr + scale_attn_pretrial_rtsresid, data=attmem_drop_na[attmem_drop_na$subject_num==i,], family=binomial(link = "logit"))
  tmp              <- data.frame(exp = numeric(0), subject_num=numeric(0), intercept=numeric(0), cr_coef=numeric(0), attn_pretrial_rtsresid_coef=numeric(0))
  tmp[1,]          <- c(unique(attmem_drop_na[attmem_drop_na$subject_num==i,]$exp), i, within_sub_model$coefficients)
  within_sub_joint_model_coefs <- rbind(within_sub_joint_model_coefs,tmp)
}

within_sub_joint_model_coefs <- within_sub_joint_model_coefs[order(within_sub_joint_model_coefs$exp, within_sub_joint_model_coefs$subject_num), ]
within_sub_joint_model_coefs$intercept                        <- as.numeric(within_sub_joint_model_coefs$intercept)
within_sub_joint_model_coefs$cr_coef                          <- as.numeric(within_sub_joint_model_coefs$cr_coef)
within_sub_joint_model_coefs$attn_pretrial_rtsresid_coef <- as.numeric(within_sub_joint_model_coefs$attn_pretrial_rtsresid_coef)

mean(within_sub_joint_model_coefs[within_sub_joint_model_coefs$exp=='exp2',]$cr_coef, na.rm = TRUE)
sd(within_sub_joint_model_coefs[within_sub_joint_model_coefs$exp=='exp2',]$cr_coef, na.rm = TRUE)
t.test(within_sub_joint_model_coefs[within_sub_joint_model_coefs$exp=='exp2',]$cr_coef,
       mu = 0, alternative = "two.sided", conf.level = 0.95)
cohen.d(within_sub_joint_model_coefs[within_sub_joint_model_coefs$exp=='exp2',]$cr_coef ~ .)

mean(within_sub_joint_model_coefs[within_sub_joint_model_coefs$exp=='exp2',]$attn_pretrial_rtsresid_coef,na.rm = TRUE)
sd(within_sub_joint_model_coefs[within_sub_joint_model_coefs$exp=='exp2',]$attn_pretrial_rtsresid_coef, na.rm = TRUE)
t.test(within_sub_joint_model_coefs[within_sub_joint_model_coefs$exp=='exp2',]$attn_pretrial_rtsresid_coef,
       mu = 0, alternative = "two.sided", conf.level = 0.95)
cohen.d(within_sub_joint_model_coefs[within_sub_joint_model_coefs$exp=='exp2',]$attn_pretrial_rtsresid_coef ~ .)

mean(within_sub_joint_model_coefs[within_sub_joint_model_coefs$exp=='exp3',]$cr_coef, na.rm = TRUE)
sd(within_sub_joint_model_coefs[within_sub_joint_model_coefs$exp=='exp3',]$cr_coef, na.rm = TRUE)
t.test(within_sub_joint_model_coefs[within_sub_joint_model_coefs$exp=='exp3',]$cr_coef,
       mu = 0, alternative = "two.sided", conf.level = 0.95)
cohen.d(within_sub_joint_model_coefs[within_sub_joint_model_coefs$exp=='exp3',]$cr_coef ~ .)

mean(within_sub_joint_model_coefs[within_sub_joint_model_coefs$exp=='exp3',]$attn_pretrial_rtsresid_coef,na.rm = TRUE)
sd(within_sub_joint_model_coefs[within_sub_joint_model_coefs$exp=='exp3',]$attn_pretrial_rtsresid_coef, na.rm = TRUE)
t.test(within_sub_joint_model_coefs[within_sub_joint_model_coefs$exp=='exp3',]$attn_pretrial_rtsresid_coef,
       mu = 0, alternative = "two.sided", conf.level = 0.95)
cohen.d(within_sub_joint_model_coefs[within_sub_joint_model_coefs$exp=='exp3',]$attn_pretrial_rtsresid_coef ~ .)

t.test(x = within_sub_joint_model_coefs[within_sub_joint_model_coefs$exp=='exp2',]$cr_coef,
       y = within_sub_joint_model_coefs[within_sub_joint_model_coefs$exp=='exp2',]$attn_pretrial_rtsresid_coef,
       paired = TRUE, var.equal = TRUE, detailed = TRUE, alternative = "two.sided", conf.level = 0.95)

t.test(x = within_sub_joint_model_coefs[within_sub_joint_model_coefs$exp=='exp3',]$cr_coef,
       y = within_sub_joint_model_coefs[within_sub_joint_model_coefs$exp=='exp3',]$attn_pretrial_rtsresid_coef,
       paired = TRUE, var.equal = TRUE, detailed = TRUE, alternative = "two.sided", conf.level = 0.95)

cohen.d(within_sub_joint_model_coefs[within_sub_joint_model_coefs$exp=='exp2',]$cr_coef,
        within_sub_joint_model_coefs[within_sub_joint_model_coefs$exp=='exp2',]$attn_pretrial_rtsresid_coef,
        paired=TRUE)

cohen.d(within_sub_joint_model_coefs[within_sub_joint_model_coefs$exp=='exp3',]$cr_coef,
        within_sub_joint_model_coefs[within_sub_joint_model_coefs$exp=='exp3',]$attn_pretrial_rtsresid_coef,
        paired=TRUE)

ttestBF(x = within_sub_joint_model_coefs[within_sub_joint_model_coefs$exp=='exp2',]$cr_coef,
        y = within_sub_joint_model_coefs[within_sub_joint_model_coefs$exp=='exp2',]$attn_pretrial_rtsresid_coef,
        paired = TRUE, var.equal = TRUE, detailed = TRUE, alternative = "two.sided", conf.level = 0.95)

ttestBF(x = within_sub_joint_model_coefs[within_sub_joint_model_coefs$exp=='exp3',]$cr_coef,
        y = within_sub_joint_model_coefs[within_sub_joint_model_coefs$exp=='exp3',]$attn_pretrial_rtsresid_coef,
        paired = TRUE, var.equal = TRUE, detailed = TRUE, alternative = "two.sided", conf.level = 0.95)

cor.test(within_sub_joint_model_coefs[within_sub_joint_model_coefs$exp=='exp2',]$cr_coef,
         within_sub_joint_model_coefs[within_sub_joint_model_coefs$exp=='exp2',]$attn_pretrial_rtsresid_coef,
         method ="spearman", conf.level = 0.95)

cor.test(within_sub_joint_model_coefs[within_sub_joint_model_coefs$exp=='exp3',]$cr_coef,
         within_sub_joint_model_coefs[within_sub_joint_model_coefs$exp=='exp3',]$attn_pretrial_rtsresid_coef,
         method ="spearman", conf.level = 0.95)

### Replicating models without within-subject z-scoring
within_sub_joint_model_coefs_noz <- data.frame(exp = numeric(0), subject_num=numeric(0), intercept=numeric(0), cr_coef=numeric(0), attn_pretrial_rtsresid_coef=numeric(0))
for (i in unique(attmem_drop_na$subject_num)){
  within_sub_model_noz <- glm(mem_remembered_thr4 ~ cr + attn_pretrial_rtsresid, data=attmem_drop_na[attmem_drop_na$subject_num==i,], family=binomial(link = "logit"))
  tmp_noz              <- data.frame(exp = numeric(0), subject_num=numeric(0), intercept=numeric(0), cr_coef=numeric(0), attn_pretrial_rtsresid_coef=numeric(0))
  tmp_noz[1,]          <- c(unique(attmem_drop_na[attmem_drop_na$subject_num==i,]$exp), i, within_sub_model_noz$coefficients)
  within_sub_joint_model_coefs_noz <- rbind(within_sub_joint_model_coefs_noz,tmp_noz)
}

within_sub_joint_model_coefs_noz <- within_sub_joint_model_coefs_noz[order(within_sub_joint_model_coefs_noz$exp, within_sub_joint_model_coefs_noz$subject_num), ]
within_sub_joint_model_coefs_noz$intercept                        <- as.numeric(within_sub_joint_model_coefs_noz$intercept)
within_sub_joint_model_coefs_noz$cr_coef                          <- as.numeric(within_sub_joint_model_coefs_noz$cr_coef)
within_sub_joint_model_coefs_noz$attn_pretrial_rtsresid_coef <- as.numeric(within_sub_joint_model_coefs_noz$attn_pretrial_rtsresid_coef)

mean(within_sub_joint_model_coefs_noz[within_sub_joint_model_coefs_noz$exp=='exp2',]$cr_coef, na.rm = TRUE)
sd(within_sub_joint_model_coefs_noz[within_sub_joint_model_coefs_noz$exp=='exp2',]$cr_coef, na.rm = TRUE)
t.test(within_sub_joint_model_coefs_noz[within_sub_joint_model_coefs_noz$exp=='exp2',]$cr_coef,
       mu = 0, alternative = "two.sided", conf.level = 0.95)
cohen.d(within_sub_joint_model_coefs_noz[within_sub_joint_model_coefs_noz$exp=='exp2',]$cr_coef ~ .)

mean(within_sub_joint_model_coefs_noz[within_sub_joint_model_coefs_noz$exp=='exp2',]$attn_pretrial_rtsresid_coef,na.rm = TRUE)
sd(within_sub_joint_model_coefs_noz[within_sub_joint_model_coefs_noz$exp=='exp2',]$attn_pretrial_rtsresid_coef, na.rm = TRUE)
t.test(within_sub_joint_model_coefs_noz[within_sub_joint_model_coefs_noz$exp=='exp2',]$attn_pretrial_rtsresid_coef,
       mu = 0, alternative = "two.sided", conf.level = 0.95)
cohen.d(within_sub_joint_model_coefs_noz[within_sub_joint_model_coefs_noz$exp=='exp2',]$attn_pretrial_rtsresid_coef ~ .)

mean(within_sub_joint_model_coefs_noz[within_sub_joint_model_coefs_noz$exp=='exp3',]$cr_coef, na.rm = TRUE)
sd(within_sub_joint_model_coefs_noz[within_sub_joint_model_coefs_noz$exp=='exp3',]$cr_coef, na.rm = TRUE)
t.test(within_sub_joint_model_coefs_noz[within_sub_joint_model_coefs_noz$exp=='exp3',]$cr_coef,
       mu = 0, alternative = "two.sided", conf.level = 0.95)
cohen.d(within_sub_joint_model_coefs_noz[within_sub_joint_model_coefs_noz$exp=='exp3',]$cr_coef ~ .)

mean(within_sub_joint_model_coefs_noz[within_sub_joint_model_coefs_noz$exp=='exp3',]$attn_pretrial_rtsresid_coef,na.rm = TRUE)
sd(within_sub_joint_model_coefs_noz[within_sub_joint_model_coefs_noz$exp=='exp3',]$attn_pretrial_rtsresid_coef, na.rm = TRUE)
t.test(within_sub_joint_model_coefs_noz[within_sub_joint_model_coefs_noz$exp=='exp3',]$attn_pretrial_rtsresid_coef,
       mu = 0, alternative = "two.sided", conf.level = 0.95)
cohen.d(within_sub_joint_model_coefs_noz[within_sub_joint_model_coefs_noz$exp=='exp3',]$attn_pretrial_rtsresid_coef ~ .)


######################## Regression models by memory accuracy ######################## 
### Create models for high-performing and low-performing individuals (excluding individuals who failed to meet exclusion criteria [3] or had outlier attention A' [1])
recogmem_perf2 <- read.csv("./data_expt2/expt2_recogmemperf.csv")%>%
  dplyr::rename(subject_num=subj_num)
recogmem_perf2 <- recogmem_perf2%>%
  dplyr::filter( subject_num != 25)
recogmem_perf2$subject_num = recogmem_perf2$subject_num+100

recogmem_perf3 <- read.csv("./data_expt3/expt3_recogmemperf.csv")%>%
  dplyr::rename(subject_num=subj_num)%>%
  dplyr::filter(subject_num != 26)
recogmem_perf3$subject_num = recogmem_perf3$subject_num+200

#calculate aprime for each condition
aprime1        <- data.frame(aprime=.5+(((recogmem_perf2$h_old_infreq-recogmem_perf2$fa_new_infreq)*(1+recogmem_perf2$h_old_infreq-recogmem_perf2$fa_new_infreq)) / (4 * recogmem_perf2$h_old_infreq*(1-recogmem_perf2$fa_new_infreq))))
recogmem_perf2 <- cbind(recogmem_perf2,aprime1)

aprime2        <- data.frame(aprime=.5+(((recogmem_perf3$h_old_infreq-recogmem_perf3$fa_new_infreq)*(1+recogmem_perf3$h_old_infreq-recogmem_perf3$fa_new_infreq)) / (4 * recogmem_perf3$h_old_infreq*(1-recogmem_perf3$fa_new_infreq))))
recogmem_perf3 <- cbind(recogmem_perf3,aprime2)

#perform median split
median1 <- median(recogmem_perf2$aprime)
median2 <- median(recogmem_perf3$aprime)

recogmem_perf2$median_split <- factor(
  ifelse(recogmem_perf2$aprime < median(recogmem_perf2$aprime), 1, 
         ifelse(recogmem_perf2$aprime >= median(recogmem_perf2$aprime), 2, NA)), 
  1:2, labels = c("below", "above"))

recogmem_perf3$median_split <- factor(
  ifelse(recogmem_perf3$aprime < median(recogmem_perf3$aprime), 1, 
         ifelse(recogmem_perf3$aprime >= median(recogmem_perf3$aprime), 2, NA)), 
  1:2, labels = c("below", "above"))

# merge with attmem_drop_na
recogmem_perf_all             <- rbind(recogmem_perf2,recogmem_perf3)
recogmem_perf_all$subject_num <- factor(recogmem_perf_all$subject_num)
attmem_drop_na                <- merge(attmem_drop_na, recogmem_perf_all, by ="subject_num", all = TRUE)

# create models
#Joint model by exp and memory success
regression_joint_full_above <- glmer(mem_remembered_thr4 ~ scale_attn_pretrial_rtsresid+scale_cr + (1 | exp/subject_num), data=attmem_drop_na[attmem_drop_na$median_split=="above",],family = binomial(link = "logit"), control = glmerControl(optimizer ='optimx', optCtrl=list(method='L-BFGS-B')))
regression_joint_full_below <- glmer(mem_remembered_thr4 ~ scale_attn_pretrial_rtsresid+scale_cr + (1 | exp/subject_num), data=attmem_drop_na[attmem_drop_na$median_split=="below",],family = binomial(link = "logit"), control = glmerControl(optimizer ='optimx', optCtrl=list(method='L-BFGS-B')))

summary(regression_joint_full_above)
summary(regression_joint_full_below)

# compare within-subject coefficients between better and worse memory groups
within_sub_joint_model_coefs$subject_num <- factor(within_sub_joint_model_coefs$subject_num)
within_sub_joint_model_coefs <- merge(within_sub_joint_model_coefs, recogmem_perf_all, by ="subject_num", all = TRUE)

t.test(x = within_sub_joint_model_coefs[within_sub_joint_model_coefs$exp=='exp2' & within_sub_joint_model_coefs$median_split=='above',]$cr_coef,
       y = within_sub_joint_model_coefs[within_sub_joint_model_coefs$exp=='exp2' & within_sub_joint_model_coefs$median_split=='below',]$cr_coef,
       paired = FALSE, var.equal = TRUE, detailed = TRUE, alternative = "two.sided", conf.level = 0.95)

t.test(x = within_sub_joint_model_coefs[within_sub_joint_model_coefs$exp=='exp2' & within_sub_joint_model_coefs$median_split=='above',]$attn_pretrial_rtsresid_coef,
       y = within_sub_joint_model_coefs[within_sub_joint_model_coefs$exp=='exp2' & within_sub_joint_model_coefs$median_split=='below',]$attn_pretrial_rtsresid_coef,
       paired = FALSE, var.equal = TRUE, detailed = TRUE, alternative = "two.sided", conf.level = 0.95)

t.test(x = within_sub_joint_model_coefs[within_sub_joint_model_coefs$exp=='exp3' & within_sub_joint_model_coefs$median_split=='above',]$cr_coef,
       y = within_sub_joint_model_coefs[within_sub_joint_model_coefs$exp=='exp3' & within_sub_joint_model_coefs$median_split=='below',]$cr_coef,
       paired = FALSE, var.equal = TRUE, detailed = TRUE, alternative = "two.sided", conf.level = 0.95)

t.test(x = within_sub_joint_model_coefs[within_sub_joint_model_coefs$exp=='exp3' & within_sub_joint_model_coefs$median_split=='above',]$attn_pretrial_rtsresid_coef,
       y = within_sub_joint_model_coefs[within_sub_joint_model_coefs$exp=='exp3' & within_sub_joint_model_coefs$median_split=='below',]$attn_pretrial_rtsresid_coef,
       paired = FALSE, var.equal = TRUE, detailed = TRUE, alternative = "two.sided", conf.level = 0.95)


ttestBF(x = within_sub_joint_model_coefs[within_sub_joint_model_coefs$exp=='exp2' & within_sub_joint_model_coefs$median_split=='above',]$cr_coef,
        y = within_sub_joint_model_coefs[within_sub_joint_model_coefs$exp=='exp2' & within_sub_joint_model_coefs$median_split=='below',]$cr_coef,
        paired = FALSE, var.equal = TRUE, detailed = TRUE, alternative = "two.sided", conf.level = 0.95)

ttestBF(x = within_sub_joint_model_coefs[within_sub_joint_model_coefs$exp=='exp2' & within_sub_joint_model_coefs$median_split=='above',]$attn_pretrial_rtsresid_coef,
        y = within_sub_joint_model_coefs[within_sub_joint_model_coefs$exp=='exp2' & within_sub_joint_model_coefs$median_split=='below',]$attn_pretrial_rtsresid_coef,
        paired = FALSE, var.equal = TRUE, detailed = TRUE, alternative = "two.sided", conf.level = 0.95)

ttestBF(x = within_sub_joint_model_coefs[within_sub_joint_model_coefs$exp=='exp3' & within_sub_joint_model_coefs$median_split=='above',]$cr_coef,
        y = within_sub_joint_model_coefs[within_sub_joint_model_coefs$exp=='exp3' & within_sub_joint_model_coefs$median_split=='below',]$cr_coef,
        paired = FALSE, var.equal = TRUE, detailed = TRUE, alternative = "two.sided", conf.level = 0.95)

ttestBF(x = within_sub_joint_model_coefs[within_sub_joint_model_coefs$exp=='exp3' & within_sub_joint_model_coefs$median_split=='above',]$attn_pretrial_rtsresid_coef,
        y = within_sub_joint_model_coefs[within_sub_joint_model_coefs$exp=='exp3' & within_sub_joint_model_coefs$median_split=='below',]$attn_pretrial_rtsresid_coef,
        paired = FALSE, var.equal = TRUE, detailed = TRUE, alternative = "two.sided", conf.level = 0.95)


######################## Cross-dataset models ######################## 
attmem_drop_na <- attmem_drop_na[order(attmem_drop_na$subject_num, attmem_drop_na$attn_trialnum), ]

#Joint model by exp
regression_joint_exp2 <- glmer(mem_remembered_thr4 ~ scale_attn_pretrial_rtsresid+scale_cr + (1 | subject_num), data=attmem_drop_na[attmem_drop_na$exp=="exp2",], family = binomial(link = "logit"), control = glmerControl(optimizer ='optimx', optCtrl=list(method='L-BFGS-B')))
regression_joint_exp3 <- glmer(mem_remembered_thr4 ~ scale_attn_pretrial_rtsresid+scale_cr + (1 | subject_num), data=attmem_drop_na[attmem_drop_na$exp=="exp3",], family = binomial(link = "logit"), control = glmerControl(optimizer ='optimx', optCtrl=list(method='L-BFGS-B')))

exp2_pred_exp3 <- predict(regression_joint_exp2, newdata = attmem_drop_na[attmem_drop_na$exp=="exp3",], 
                          newparams = NULL, re.form = NA, random.only=FALSE, terms = NULL,
                          type = "link", allow.new.levels = FALSE,
                          na.action = na.pass)

exp3_pred_exp2 <- predict(regression_joint_exp3, newdata = attmem_drop_na[attmem_drop_na$exp=="exp2",], 
                          newparams = NULL, re.form = NA, random.only=FALSE, terms = NULL,
                          type = "link", allow.new.levels = FALSE,
                          na.action = na.pass)

preds           <- rbind(as.data.frame(as.matrix(exp3_pred_exp2)),as.data.frame(as.matrix(exp2_pred_exp3)))
colnames(preds) <- c("preds")

attmem_drop_na <- cbind(attmem_drop_na,preds)

# create new data frame
pred_r             <- by(attmem_drop_na, attmem_drop_na$subject_num, function(x) {cor(x$mem_remembered_thr4, x$preds, method="pearson")})
pred_r             <- cbind(as.data.frame(unique(attmem_drop_na$subject_num)),as.data.frame(as.matrix(pred_r)))
colnames(pred_r)   <- c("subject_num","r")
pred_r$subject_num_numeric <- as.numeric(as.character((pred_r$subject_num)))

exp3_rep_pred_exp2_r <- FisherZInv(mean(FisherZ(pred_r[pred_r$subject_num_numeric<200,]$r)))
exp2_rep_pred_exp3_r <- FisherZInv(mean(FisherZ(pred_r[pred_r$subject_num_numeric>=200,]$r)))

# group-level significance testing
exp2_pred_exp3_rep_t <- t.test(FisherZ(pred_r[pred_r$subject_num_numeric>=200,]$r),
                               mu = 0, alternative = "two.sided", conf.level = 0.95)
exp2_pred_exp3_rep_t$parameter
exp2_pred_exp3_rep_t$statistic
exp2_pred_exp3_rep_t$p.value
FisherZInv(exp2_pred_exp3_rep_t$estimate)
FisherZInv(exp2_pred_exp3_rep_t$conf.int)

exp3_rep_pred_exp2_t <- t.test(FisherZ(pred_r[pred_r$subject_num_numeric<200,]$r),
                               mu = 0, alternative = "two.sided", conf.level = 0.95)
exp3_rep_pred_exp2_t$parameter
exp3_rep_pred_exp2_t$statistic
exp3_rep_pred_exp2_t$p.value
FisherZInv(exp3_rep_pred_exp2_t$estimate)
FisherZInv(exp3_rep_pred_exp2_t$conf.int)

cohen.d(FisherZ(pred_r[pred_r$subject_num_numeric>=200,]$r)~ .)
cohen.d(FisherZ(pred_r[pred_r$subject_num_numeric<200,]$r)~ .)

ttestBF(FisherZ(pred_r[pred_r$subject_num_numeric>=200,]$r),
        alternative = "two.sided", conf.level = 0.95)
ttestBF(FisherZ(pred_r[pred_r$subject_num_numeric<200,]$r),
        alternative = "two.sided", conf.level = 0.95)


# sessionInfo()
# R version 4.0.3 (2020-10-10)
# Platform: x86_64-apple-darwin17.0 (64-bit)
# Running under: macOS Catalina 10.15.7

# Matrix products: default
# BLAS:   /System/Library/Frameworks/Accelerate.framework/Versions/A/Frameworks/vecLib.framework/Versions/A/libBLAS.dylib
# LAPACK: /Library/Frameworks/R.framework/Versions/4.0/Resources/lib/libRlapack.dylib

# locale:
# [1] en_US.UTF-8/en_US.UTF-8/en_US.UTF-8/C/en_US.UTF-8/en_US.UTF-8

# attached base packages:
# [1] stats     graphics  grDevices utils     datasets  methods   base     

# other attached packages:
# sjstats_0.18.1 DescTools_0.99.42 mousetrap_3.2.0 effsize_0.8.1 BayesFactor_0.9.12-4.2 coda_0.19-4 optimx_2020-4.2 lme4_1.1-26 Matrix_1.2-18 forcats_0.5.0 stringr_1.4.0 dplyr_1.0.2 purrr_0.3.4 readr_1.4.0 tidyr_1.1.2 tibble_3.0.4 ggplot2_3.3.2 tidyverse_1.3.0

# loaded via a namespace (and not attached): nlme_3.1-149 fs_1.5.0 lubridate_1.7.9.2 insight_0.14.4 httr_1.4.2 numDeriv_2016.8-1.1 tools_4.0.3 backports_1.2.0 sjlabelled_1.1.7 R6_2.5.0 DBI_1.1.0 colorspace_2.0-0 withr_2.4.2 tidyselect_1.1.0 Exact_2.1 emmeans_1.6.3 compiler_4.0.3 performance_0.7.3 cli_3.0.1 rvest_0.3.6 expm_0.999-6 xml2_1.3.2 sandwich_3.0-0 labeling_0.4.2 bayestestR_0.9.0 scales_1.1.1 mvtnorm_1.1-1 pbapply_1.4-3 proxy_0.4-26 digest_0.6.27 minqa_1.2.4 pkgconfig_2.0.3 dbplyr_2.0.0 rlang_0.4.11 readxl_1.3.1 rstudioapi_0.13 farver_2.0.3 generics_0.1.0 zoo_1.8-9 jsonlite_1.7.1 gtools_3.9.2 magrittr_2.0.1 parameters_0.14.0 Rcpp_1.0.5 munsell_0.5.0 lifecycle_1.0.0 stringi_1.5.3 multcomp_1.4-16 MASS_7.3-53 rootSolve_1.8.2.1 grid_4.0.3 parallel_4.0.3 sjmisc_2.8.7 crayon_1.3.4 lmom_2.8 lattice_0.20-41 haven_2.3.1 splines_4.0.3 hms_0.5.3 pillar_1.4.7 boot_1.3-25 gld_2.6.2 estimability_1.3 effectsize_0.4.5 codetools_0.2-16 reprex_0.3.0 glue_1.4.2 data.table_1.13.2 modelr_0.1.8 vctrs_0.3.5 nloptr_1.2.2.2 MatrixModels_0.4-1 cellranger_1.1.0 gtable_0.3.0 assertthat_0.2.1 xfun_0.19 xtable_1.8-4 broom_0.7.2 e1071_1.7-7 class_7.3-17 survival_3.2-7 tinytex_0.27 statmod_1.4.35 TH.data_1.0-10 ellipsis_0.3.1